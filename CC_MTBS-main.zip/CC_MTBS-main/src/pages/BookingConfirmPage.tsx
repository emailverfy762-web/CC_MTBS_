import { useLocation, useNavigate, Link } from 'react-router-dom';
import { CheckCircle, Ticket, Calendar, Clock, MapPin, Users, Download, Home } from 'lucide-react';
import { Booking, Movie, Show } from '../types';

export default function BookingConfirmPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as { booking: Booking; movie: Movie; show: Show } | null;

  if (!state) {
    navigate('/');
    return null;
  }

  const { booking, movie, show } = state;
  const bk = booking as Booking & { movieTitle?: string; theaterName?: string; showTime?: string; showDate?: string };
  const theaterName = bk.theaterName || 'Theater';
  const convFee = Math.round(booking.totalAmount * 0.05);

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">
        {/* Success Animation */}
        <div className="text-center mb-8">
          <div className="relative inline-block">
            <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
              <div className="w-14 h-14 bg-green-500/30 rounded-full flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-green-400" />
              </div>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Booking Confirmed! 🎉</h1>
          <p className="text-gray-400">Your tickets have been booked successfully</p>
        </div>

        {/* Ticket Card */}
        <div className="bg-gray-900 rounded-2xl border border-gray-700 overflow-hidden shadow-2xl">
          {/* Top Section */}
          <div className="bg-gradient-to-r from-red-900/40 to-gray-900 p-6 border-b border-gray-700">
            <div className="flex items-start gap-4">
              <img
                src={movie.posterUrl}
                alt={movie.title}
                className="w-16 h-24 rounded-lg object-cover border border-gray-600 flex-shrink-0"
                onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/100x150/1a1a2e/ffffff?text=Movie'; }}
              />
              <div>
                <h2 className="text-xl font-bold text-white mb-1">{movie.title}</h2>
                <div className="flex flex-wrap gap-1 mb-2">
                  {movie.genre.slice(0, 2).map(g => (
                    <span key={g} className="text-xs bg-gray-800 text-gray-300 px-2 py-0.5 rounded-full">{g}</span>
                  ))}
                  <span className="text-xs bg-gray-800 text-gray-300 px-2 py-0.5 rounded-full">{movie.language}</span>
                </div>
                <div className="bg-green-600/20 border border-green-600/30 rounded-lg px-3 py-1 inline-block">
                  <p className="text-green-400 text-xs font-mono font-bold">REF: {booking.bookingRef}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Dashed Divider */}
          <div className="relative">
            <div className="absolute left-0 w-6 h-6 bg-gray-950 rounded-full -translate-y-1/2 -translate-x-1/2 border-r border-gray-700" />
            <div className="border-t-2 border-dashed border-gray-700 mx-6" />
            <div className="absolute right-0 w-6 h-6 bg-gray-950 rounded-full -translate-y-1/2 translate-x-1/2 border-l border-gray-700" />
          </div>

          {/* Details Grid */}
          <div className="p-6 grid grid-cols-2 gap-4">
            <div className="flex items-start gap-2">
              <Calendar className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-gray-400 text-xs mb-0.5">Date</p>
                <p className="text-white font-semibold text-sm">
                  {new Date(show.date + 'T00:00:00').toLocaleDateString('en', { weekday: 'short', month: 'long', day: 'numeric' })}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Clock className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-gray-400 text-xs mb-0.5">Time</p>
                <p className="text-white font-semibold text-sm">{show.time}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 col-span-2">
              <MapPin className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-gray-400 text-xs mb-0.5">Theater</p>
                <p className="text-white font-semibold text-sm">{theaterName}</p>

              </div>
            </div>
            <div className="flex items-start gap-2 col-span-2">
              <Users className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-gray-400 text-xs mb-0.5">Seats</p>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {booking.seats.map(seat => (
                    <span key={seat} className="bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-bold px-2 py-1 rounded-lg">
                      {seat}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Dashed Divider */}
          <div className="relative">
            <div className="absolute left-0 w-6 h-6 bg-gray-950 rounded-full -translate-y-1/2 -translate-x-1/2 border-r border-gray-700" />
            <div className="border-t-2 border-dashed border-gray-700 mx-6" />
            <div className="absolute right-0 w-6 h-6 bg-gray-950 rounded-full -translate-y-1/2 translate-x-1/2 border-l border-gray-700" />
          </div>

          {/* Price Section */}
          <div className="p-6 space-y-2">
            <div className="flex justify-between text-sm text-gray-400">
              <span>{booking.seats.length} Ticket(s)</span>
              <span>₹{booking.totalAmount}</span>
            </div>
            <div className="flex justify-between text-sm text-gray-400">
              <span>Convenience Fee (5%)</span>
              <span>₹{convFee}</span>
            </div>
            <div className="flex justify-between text-base font-bold text-white border-t border-gray-700 pt-3 mt-3">
              <span>Total Paid</span>
              <span className="text-green-400">₹{booking.totalAmount + convFee}</span>
            </div>
          </div>

          {/* Barcode */}
          <div className="px-6 pb-6 text-center">
            <div className="bg-gray-800 rounded-xl p-4">
              <div className="flex justify-center gap-0.5 mb-2">
                {Array.from({ length: 40 }, (_, i) => (
                  <div
                    key={i}
                    className="bg-white rounded-sm"
                    style={{
                      width: i % 3 === 0 ? '3px' : '2px',
                      height: `${20 + (i % 5) * 8}px`,
                    }}
                  />
                ))}
              </div>
              <p className="text-gray-400 text-xs font-mono">{booking.bookingRef}</p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 grid grid-cols-2 gap-3">
          <button
            onClick={() => window.print()}
            className="flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 py-3 rounded-xl font-medium transition-colors border border-gray-700"
          >
            <Download className="w-4 h-4" /> Print Ticket
          </button>
          <Link
            to="/my-bookings"
            className="flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 py-3 rounded-xl font-medium transition-colors border border-gray-700"
          >
            <Ticket className="w-4 h-4" /> My Bookings
          </Link>
        </div>
        <Link to="/" className="flex items-center justify-center gap-2 mt-3 bg-red-600 hover:bg-red-500 text-white py-3 rounded-xl font-bold transition-colors shadow-lg shadow-red-900/30">
          <Home className="w-4 h-4" /> Back to Home
        </Link>
      </div>
    </div>
  );
}
