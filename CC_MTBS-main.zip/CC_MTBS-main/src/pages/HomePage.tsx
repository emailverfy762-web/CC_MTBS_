import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Star, Play, Film, Ticket, Users, Award, ChevronLeft } from 'lucide-react';
import { Movie } from '../types';
import { sbGetMovies } from '../lib/supabaseDb';
import MovieCard from '../components/MovieCard';

export default function HomePage() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [heroIndex, setHeroIndex] = useState(0);

  useEffect(() => {
    sbGetMovies().then(setMovies);
  }, []);

  const nowShowing = movies.filter(m => m.status === 'now_showing');
  const comingSoon = movies.filter(m => m.status === 'coming_soon');
  const heroMovies = nowShowing.slice(0, 4);

  useEffect(() => {
    if (heroMovies.length === 0) return;
    const timer = setInterval(() => {
      setHeroIndex(prev => (prev + 1) % heroMovies.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [heroMovies.length]);

  const hero = heroMovies[heroIndex];

  const stats = [
    { icon: Film, label: 'Movies', value: '500+' },
    { icon: Ticket, label: 'Bookings Daily', value: '10K+' },
    { icon: Users, label: 'Happy Users', value: '50K+' },
    { icon: Award, label: 'Awards', value: '25+' },
  ];

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Hero Section */}
      {hero && (
        <div className="relative h-[85vh] overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
            style={{ backgroundImage: `url(${hero.bannerUrl})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-transparent to-transparent" />

          <div className="relative z-10 h-full flex items-center">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
              <div className="max-w-lg">
                <div className="flex items-center gap-3 mb-4">
                  <span className="bg-red-600 text-white text-xs px-3 py-1 rounded-full font-semibold uppercase tracking-wide">Now Showing</span>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    <span className="text-yellow-400 font-semibold">{hero.imdbRating}</span>
                    <span className="text-gray-400 text-sm">/ 10</span>
                  </div>
                </div>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
                  {hero.title}
                </h1>
                <div className="flex flex-wrap gap-2 mb-4">
                  {hero.genre.map(g => (
                    <span key={g} className="bg-white/10 backdrop-blur text-white text-xs px-3 py-1 rounded-full border border-white/20">{g}</span>
                  ))}
                </div>
                <p className="text-gray-300 text-sm md:text-base mb-6 line-clamp-3 leading-relaxed">{hero.description}</p>
                <div className="flex gap-3">
                  <Link
                    to={`/movies/${hero.id}`}
                    className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-6 py-3 rounded-xl font-semibold transition-all hover:scale-105 shadow-lg shadow-red-900/50"
                  >
                    <Ticket className="w-5 h-5" /> Book Tickets
                  </Link>
                  <Link
                    to={`/movies/${hero.id}`}
                    className="flex items-center gap-2 bg-white/10 backdrop-blur hover:bg-white/20 text-white px-6 py-3 rounded-xl font-semibold transition-all border border-white/20"
                  >
                    <Play className="w-5 h-5" /> More Info
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Hero Controls */}
          <div className="absolute bottom-8 right-8 flex items-center gap-2 z-10">
            <button onClick={() => setHeroIndex(p => (p - 1 + heroMovies.length) % heroMovies.length)} className="bg-white/10 hover:bg-white/20 backdrop-blur p-2 rounded-full transition-colors">
              <ChevronLeft className="w-5 h-5 text-white" />
            </button>
            <div className="flex gap-2">
              {heroMovies.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setHeroIndex(i)}
                  className={`h-1.5 rounded-full transition-all ${i === heroIndex ? 'w-8 bg-red-500' : 'w-2 bg-white/30'}`}
                />
              ))}
            </div>
            <button onClick={() => setHeroIndex(p => (p + 1) % heroMovies.length)} className="bg-white/10 hover:bg-white/20 backdrop-blur p-2 rounded-full transition-colors">
              <ChevronRight className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="bg-gray-900 border-y border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map(({ icon: Icon, label, value }) => (
              <div key={label} className="text-center">
                <div className="flex justify-center mb-2">
                  <div className="bg-red-600/20 p-3 rounded-xl">
                    <Icon className="w-6 h-6 text-red-500" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-white">{value}</p>
                <p className="text-gray-400 text-sm">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Now Showing */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white">Now Showing</h2>
            <p className="text-gray-400 text-sm mt-1">Book your seats for today's top movies</p>
          </div>
          <Link to="/movies" className="flex items-center gap-1 text-red-400 hover:text-red-300 text-sm font-medium transition-colors">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {nowShowing.map(movie => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      </section>

      {/* Coming Soon */}
      {comingSoon.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-16">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-white">Coming Soon</h2>
              <p className="text-gray-400 text-sm mt-1">Upcoming blockbusters</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {comingSoon.map(movie => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        </section>
      )}

      {/* CTA Banner */}
      <div className="bg-gradient-to-r from-red-900 via-red-800 to-red-900 border-t border-red-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <Film className="w-12 h-12 text-red-300 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-white mb-3">Experience Movies Like Never Before</h2>
          <p className="text-red-200 mb-6 max-w-lg mx-auto">Book your seats in seconds. Best seats, best prices, zero hassle.</p>
          <Link to="/movies" className="inline-flex items-center gap-2 bg-white text-red-700 px-8 py-3 rounded-xl font-bold hover:bg-red-50 transition-colors shadow-xl">
            <Ticket className="w-5 h-5" /> Book Now
          </Link>
        </div>
      </div>
    </div>
  );
}
