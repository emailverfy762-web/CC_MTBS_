import { useState, useEffect } from 'react';
import {
  LayoutDashboard, Film, Users, Ticket, Theater, Plus, Trash2, Edit3,
  TrendingUp, Star, X, Save
} from 'lucide-react';
import {
  sbGetMovies, sbAddMovie, sbUpdateMovie, sbDeleteMovie,
  sbGetTheaters, sbAddTheater, sbDeleteTheater,
  sbGetUsers, sbGetBookings,
  sbGetShows, sbAddShow
} from '../lib/supabaseDb';
import { supabase } from '../lib/supabase';
import { Movie, User, Booking, Theater as TheaterType, Show } from '../types';

type Tab = 'dashboard' | 'movies' | 'users' | 'bookings' | 'theaters' | 'shows';

export default function AdminPage() {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [movies, setMovies] = useState<Movie[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [theaters, setTheaters] = useState<TheaterType[]>([]);
  const [shows, setShows] = useState<Show[]>([]);
  const [showMovieForm, setShowMovieForm] = useState(false);
  const [showTheaterForm, setShowTheaterForm] = useState(false);
  const [showShowForm, setShowShowForm] = useState(false);
  const [editMovie, setEditMovie] = useState<Movie | null>(null);

  const [showForm, setShowForm] = useState({
    movieId: '', date: '', price: 150,
    theaterSlots: [{ theaterId: '', time: '10:00' }] as { theaterId: string; time: string }[],
  });

  const [movieForm, setMovieForm] = useState({
    title: '', genre: '', language: 'English', duration: 120, rating: 'PG-13',
    imdbRating: 7.0, description: '', posterUrl: '', releaseDate: '', director: '', cast: '', status: 'now_showing' as Movie['status']
  });
  const [theaterForm, setTheaterForm] = useState({ name: '', location: '', totalSeats: 60 });
  const [saveMsg, setSaveMsg] = useState('');

  useEffect(() => {
    refresh();
  }, []);

  const refresh = async () => {
    const [m, t, u, b, s] = await Promise.all([sbGetMovies(), sbGetTheaters(), sbGetUsers(), sbGetBookings(), sbGetShows()]);
    setMovies(m);
    setTheaters(t);
    setUsers(u);
    setBookings(b);
    setShows(s);
  };

  const handleMovieSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const movie: Movie = {
      id: editMovie?.id || 'm' + Date.now(),
      title: movieForm.title,
      genre: movieForm.genre.split(',').map(g => g.trim()).filter(Boolean),
      language: movieForm.language,
      duration: Number(movieForm.duration),
      rating: movieForm.rating,
      imdbRating: Number(movieForm.imdbRating),
      description: movieForm.description,
      posterUrl: movieForm.posterUrl || `https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&h=600&fit=crop`,
      bannerUrl: movieForm.posterUrl || `https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200&h=400&fit=crop`,
      releaseDate: movieForm.releaseDate,
      cast: movieForm.cast.split(',').map(c => c.trim()).filter(Boolean),
      director: movieForm.director,
      status: movieForm.status,
    };

    if (editMovie) {
      await sbUpdateMovie(movie);
      setSaveMsg('Movie updated successfully!');
    } else {
      await sbAddMovie(movie);
      setSaveMsg('Movie added successfully!');
    }

    refresh();
    setShowMovieForm(false);
    setEditMovie(null);
    resetMovieForm();
    setTimeout(() => setSaveMsg(''), 3000);
  };

  const handleDeleteMovie = async (id: string) => {
    if (!confirm('Delete this movie?')) return;
    await sbDeleteMovie(id);
    refresh();
  };

  const handleEditMovie = (movie: Movie) => {
    setEditMovie(movie);
    setMovieForm({
      title: movie.title, genre: movie.genre.join(', '), language: movie.language,
      duration: movie.duration, rating: movie.rating, imdbRating: movie.imdbRating,
      description: movie.description, posterUrl: movie.posterUrl,
      releaseDate: movie.releaseDate, director: movie.director,
      cast: movie.cast.join(', '), status: movie.status,
    });
    setShowMovieForm(true);
  };

  const resetMovieForm = () => {
    setMovieForm({ title: '', genre: '', language: 'English', duration: 120, rating: 'PG-13', imdbRating: 7.0, description: '', posterUrl: '', releaseDate: '', director: '', cast: '', status: 'now_showing' });
  };

  const handleTheaterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await sbAddTheater({ id: 't' + Date.now(), ...theaterForm });
    refresh();
    setShowTheaterForm(false);
    setTheaterForm({ name: '', location: '', totalSeats: 60 });
    setSaveMsg('Theater added!');
    setTimeout(() => setSaveMsg(''), 3000);
  };

  const generateSeats = (totalSeats: number): string[] => {
    const rows = ['A','B','C','D','E','F','G','H','I','J'];
    const seatsPerRow = Math.ceil(totalSeats / rows.length);
    const allSeats: string[] = [];
    for (const row of rows) {
      for (let i = 1; i <= seatsPerRow && allSeats.length < totalSeats; i++) {
        allSeats.push(`${row}${i}`);
      }
    }
    return allSeats;
  };

  const handleShowSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validSlots = showForm.theaterSlots.filter(s => s.theaterId && s.time);
    if (validSlots.length === 0) { alert('Please add at least one theater with a time.'); return; }
    let count = 0;
    for (const slot of validSlots) {
      const theater = theaters.find(t => t.id === slot.theaterId);
      if (!theater) continue;
      const show: Show = {
        id: 's' + Date.now() + count,
        movieId: showForm.movieId,
        theaterId: slot.theaterId,
        date: showForm.date,
        time: slot.time,
        price: Number(showForm.price),
        availableSeats: generateSeats(theater.totalSeats),
        bookedSeats: [],
      };
      await sbAddShow(show);
      count++;
    }
    refresh();
    setShowShowForm(false);
    setShowForm({ movieId: '', date: '', price: 150, theaterSlots: [{ theaterId: '', time: '10:00' }] });
    setSaveMsg(`${count} show(s) scheduled successfully!`);
    setTimeout(() => setSaveMsg(''), 3000);
  };

  const handleDeleteShow = async (id: string) => {
    if (!confirm('Delete this show?')) return;
    await supabase.from('shows').delete().eq('id', id);
    refresh();
  };

  const totalRevenue = bookings.filter(b => b.status === 'confirmed').reduce((sum, b) => sum + b.totalAmount, 0);

  const tabs: { id: Tab; label: string; icon: React.ReactNode; count?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'movies', label: 'Movies', icon: <Film className="w-4 h-4" />, count: movies.length },
    { id: 'shows', label: 'Shows', icon: <Ticket className="w-4 h-4" />, count: shows.length },
    { id: 'users', label: 'Users', icon: <Users className="w-4 h-4" />, count: users.length },
    { id: 'bookings', label: 'Bookings', icon: <Ticket className="w-4 h-4" />, count: bookings.length },
    { id: 'theaters', label: 'Theaters', icon: <Theater className="w-4 h-4" />, count: theaters.length },
  ];

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Admin Header */}
      <div className="bg-gray-900 border-b border-gray-800 px-4 sm:px-6 lg:px-8 py-5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <LayoutDashboard className="w-6 h-6 text-red-500" /> Admin Panel
            </h1>
            <p className="text-gray-400 text-sm mt-0.5">CC Management Dashboard</p>
          </div>
          {saveMsg && (
            <div className="bg-green-900/40 border border-green-700/40 text-green-400 text-sm px-4 py-2 rounded-xl">
              ✓ {saveMsg}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-colors border ${
                tab === t.id ? 'bg-red-600 border-red-600 text-white' : 'bg-gray-900 border-gray-700 text-gray-300 hover:text-white hover:border-gray-600'
              }`}
            >
              {t.icon} {t.label}
              {t.count !== undefined && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${tab === t.id ? 'bg-red-500 text-white' : 'bg-gray-700 text-gray-300'}`}>
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* DASHBOARD */}
        {tab === 'dashboard' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Total Movies', value: movies.length, icon: <Film className="w-5 h-5" />, color: 'bg-blue-600/20 text-blue-400 border-blue-700/30' },
                { label: 'Registered Users', value: users.length, icon: <Users className="w-5 h-5" />, color: 'bg-purple-600/20 text-purple-400 border-purple-700/30' },
                { label: 'Total Bookings', value: bookings.length, icon: <Ticket className="w-5 h-5" />, color: 'bg-green-600/20 text-green-400 border-green-700/30' },
                { label: 'Revenue (₹)', value: `₹${totalRevenue.toLocaleString()}`, icon: <TrendingUp className="w-5 h-5" />, color: 'bg-red-600/20 text-red-400 border-red-700/30' },
              ].map(({ label, value, icon, color }) => (
                <div key={label} className={`bg-gray-900 border rounded-2xl p-5 ${color.split(' ')[2]}`}>
                  <div className={`inline-flex p-2 rounded-xl mb-3 ${color.split(' ')[0]} ${color.split(' ')[1]}`}>{icon}</div>
                  <p className="text-2xl font-bold text-white">{value}</p>
                  <p className="text-gray-400 text-sm mt-0.5">{label}</p>
                </div>
              ))}
            </div>

            {/* Top Movies */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-400" /> Top Rated Movies
              </h2>
              <div className="space-y-3">
                {[...movies].sort((a, b) => b.imdbRating - a.imdbRating).slice(0, 5).map((movie, i) => (
                  <div key={movie.id} className="flex items-center gap-3">
                    <span className="text-gray-500 text-sm font-bold w-5">#{i + 1}</span>
                    <img src={movie.posterUrl} alt={movie.title} className="w-8 h-12 rounded object-cover border border-gray-700 flex-shrink-0"
                      onError={e => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/50x75/1a1a2e/fff?text=M'; }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-medium text-sm truncate">{movie.title}</p>
                      <p className="text-gray-400 text-xs">{movie.genre.slice(0, 2).join(', ')}</p>
                    </div>
                    <div className="flex items-center gap-1 bg-yellow-500/10 px-2 py-1 rounded-full">
                      <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                      <span className="text-yellow-400 text-xs font-bold">{movie.imdbRating}</span>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${movie.status === 'now_showing' ? 'bg-green-900/40 text-green-400' : 'bg-yellow-900/40 text-yellow-400'}`}>
                      {movie.status === 'now_showing' ? 'Showing' : 'Soon'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* DB Schema Info */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
              <h2 className="text-lg font-bold text-white mb-3">🗄️ MySQL Database Schema</h2>
              <p className="text-gray-400 text-xs mb-3">Connection: <span className="text-green-400 font-mono">mysql -u root -h localhost cc</span> (No Password)</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
                {[
                  { table: 'users', cols: 'id, name, email, password, role, createdAt' },
                  { table: 'movies', cols: 'id, title, genre, language, duration, rating, imdbRating, status' },
                  { table: 'theaters', cols: 'id, name, location, totalSeats' },
                  { table: 'shows', cols: 'id, movieId, theaterId, date, time, price, availableSeats, bookedSeats' },
                  { table: 'bookings', cols: 'id, userId, movieId, showId, seats, totalAmount, bookingRef, status' },
                ].map(({ table, cols }) => (
                  <div key={table} className="bg-gray-800 rounded-xl p-3">
                    <p className="text-blue-400 font-bold mb-1">TABLE: {table}</p>
                    <p className="text-gray-400 leading-relaxed">{cols}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* MOVIES */}
        {tab === 'movies' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">Manage Movies ({movies.length})</h2>
              <button
                onClick={() => { setShowMovieForm(!showMovieForm); setEditMovie(null); resetMovieForm(); }}
                className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors"
              >
                {showMovieForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                {showMovieForm ? 'Cancel' : 'Add Movie'}
              </button>
            </div>

            {/* Movie Form */}
            {showMovieForm && (
              <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5 mb-6">
                <h3 className="text-white font-bold mb-4">{editMovie ? '✏️ Edit Movie' : '🎬 Add New Movie'}</h3>
                <form onSubmit={handleMovieSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { label: 'Title', key: 'title', type: 'text', placeholder: 'Movie title' },
                    { label: 'Director', key: 'director', type: 'text', placeholder: 'Director name' },
                    { label: 'Genre (comma separated)', key: 'genre', type: 'text', placeholder: 'Action, Drama, Sci-Fi' },
                    { label: 'Cast (comma separated)', key: 'cast', type: 'text', placeholder: 'Actor1, Actor2, Actor3' },
                    { label: 'Release Date', key: 'releaseDate', type: 'date', placeholder: '' },
                    { label: 'Poster URL', key: 'posterUrl', type: 'url', placeholder: 'https://...' },
                    { label: 'Duration (minutes)', key: 'duration', type: 'number', placeholder: '120' },
                    { label: 'IMDB Rating', key: 'imdbRating', type: 'number', placeholder: '7.5' },
                  ].map(({ label, key, type, placeholder }) => (
                    <div key={key}>
                      <label className="block text-xs text-gray-400 mb-1 font-medium uppercase tracking-wide">{label}</label>
                      <input
                        type={type}
                        value={(movieForm as any)[key]}
                        onChange={e => setMovieForm(f => ({ ...f, [key]: e.target.value }))}
                        placeholder={placeholder}
                        required={['title', 'director', 'genre', 'releaseDate'].includes(key)}
                        min={key === 'imdbRating' ? 0 : key === 'duration' ? 1 : undefined}
                        max={key === 'imdbRating' ? 10 : undefined}
                        step={key === 'imdbRating' ? 0.1 : undefined}
                        className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500 placeholder-gray-500"
                      />
                    </div>
                  ))}
                  <div>
                    <label className="block text-xs text-gray-400 mb-1 font-medium uppercase tracking-wide">Language</label>
                    <select value={movieForm.language} onChange={e => setMovieForm(f => ({ ...f, language: e.target.value }))}
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500">
                      {['English', 'Hindi', 'Tamil', 'Telugu', 'Malayalam'].map(l => <option key={l} value={l}>{l}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1 font-medium uppercase tracking-wide">Status</label>
                    <select value={movieForm.status} onChange={e => setMovieForm(f => ({ ...f, status: e.target.value as Movie['status'] }))}
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500">
                      <option value="now_showing">Now Showing</option>
                      <option value="coming_soon">Coming Soon</option>
                      <option value="ended">Ended</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-xs text-gray-400 mb-1 font-medium uppercase tracking-wide">Description</label>
                    <textarea
                      value={movieForm.description}
                      onChange={e => setMovieForm(f => ({ ...f, description: e.target.value }))}
                      placeholder="Movie description..."
                      rows={3}
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500 placeholder-gray-500 resize-none"
                    />
                  </div>
                  <div className="md:col-span-2 flex gap-3">
                    <button type="submit" className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors">
                      <Save className="w-4 h-4" /> {editMovie ? 'Update Movie' : 'Save Movie'}
                    </button>
                    <button type="button" onClick={() => { setShowMovieForm(false); setEditMovie(null); resetMovieForm(); }}
                      className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors border border-gray-700">
                      <X className="w-4 h-4" /> Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Movie Table */}
            <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-800 bg-gray-800/50">
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Movie</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden md:table-cell">Genre</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden sm:table-cell">Rating</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Status</th>
                      <th className="text-right px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {movies.map(movie => (
                      <tr key={movie.id} className="hover:bg-gray-800/30 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <img src={movie.posterUrl} alt={movie.title} className="w-8 h-12 rounded object-cover border border-gray-700 flex-shrink-0"
                              onError={e => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40x60/1a1a2e/fff?text=M'; }} />
                            <div>
                              <p className="text-white text-sm font-medium">{movie.title}</p>
                              <p className="text-gray-400 text-xs">{movie.director} • {movie.duration}min</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          <div className="flex flex-wrap gap-1">
                            {movie.genre.slice(0, 2).map(g => <span key={g} className="text-xs bg-gray-800 text-gray-300 px-2 py-0.5 rounded-full">{g}</span>)}
                          </div>
                        </td>
                        <td className="px-4 py-3 hidden sm:table-cell">
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                            <span className="text-white text-sm font-medium">{movie.imdbRating}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-1 rounded-full font-semibold ${movie.status === 'now_showing' ? 'bg-green-900/40 text-green-400' : movie.status === 'coming_soon' ? 'bg-yellow-900/40 text-yellow-400' : 'bg-gray-700 text-gray-400'}`}>
                            {movie.status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-end gap-2">
                            <button onClick={() => handleEditMovie(movie)} className="p-1.5 text-gray-400 hover:text-blue-400 hover:bg-blue-900/20 rounded-lg transition-colors">
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button onClick={() => handleDeleteMovie(movie.id)} className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-900/20 rounded-lg transition-colors">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* SHOWS */}
        {tab === 'shows' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">Manage Shows ({shows.length})</h2>
              <button
                onClick={() => setShowShowForm(!showShowForm)}
                className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors"
              >
                {showShowForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                {showShowForm ? 'Cancel' : 'Schedule Show'}
              </button>
            </div>

            {showShowForm && (
              <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5 mb-6">
                <h3 className="text-white font-bold mb-4">🎬 Schedule New Show</h3>
                <form onSubmit={handleShowSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1 font-medium uppercase tracking-wide">Movie</label>
                    <select value={showForm.movieId} onChange={e => setShowForm(f => ({ ...f, movieId: e.target.value }))} required
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500">
                      <option value="">Select a movie...</option>
                      {movies.map(m => <option key={m.id} value={m.id}>{m.title}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1 font-medium uppercase tracking-wide">Date</label>
                    <input type="date" value={showForm.date} min={new Date().toISOString().split('T')[0]}
                      onChange={e => setShowForm(f => ({ ...f, date: e.target.value }))} required
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500" />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1 font-medium uppercase tracking-wide">Ticket Price (₹)</label>
                    <input type="number" value={showForm.price} min={50} max={2000}
                      onChange={e => setShowForm(f => ({ ...f, price: Number(e.target.value) }))} required
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500" />
                  </div>
                  {/* Theater + Time Slots */}
                  <div className="md:col-span-2">
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-xs text-gray-400 font-medium uppercase tracking-wide">Theaters & Show Times</label>
                      <button type="button"
                        onClick={() => setShowForm(f => ({ ...f, theaterSlots: [...f.theaterSlots, { theaterId: '', time: '10:00' }] }))}
                        className="flex items-center gap-1 text-xs bg-gray-700 hover:bg-gray-600 text-white px-3 py-1.5 rounded-lg transition-colors">
                        <Plus className="w-3 h-3" /> Add Theater
                      </button>
                    </div>
                    <div className="space-y-2">
                      {showForm.theaterSlots.map((slot, idx) => (
                        <div key={idx} className="flex gap-2 items-center bg-gray-800 border border-gray-700 rounded-xl p-3">
                          <span className="text-gray-500 text-xs font-bold w-5 shrink-0">#{idx + 1}</span>
                          <select value={slot.theaterId}
                            onChange={e => setShowForm(f => { const slots = [...f.theaterSlots]; slots[idx] = { ...slots[idx], theaterId: e.target.value }; return { ...f, theaterSlots: slots }; })}
                            required
                            className="flex-1 bg-gray-900 border border-gray-600 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500">
                            <option value="">Select theater...</option>
                            {theaters.map(t => <option key={t.id} value={t.id}>{t.name} — {t.location}</option>)}
                          </select>
                          <select value={slot.time}
                            onChange={e => setShowForm(f => { const slots = [...f.theaterSlots]; slots[idx] = { ...slots[idx], time: e.target.value }; return { ...f, theaterSlots: slots }; })}
                            className="bg-gray-900 border border-gray-600 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500 w-28 shrink-0">
                            {['09:00','10:00','11:00','12:30','13:00','14:30','15:00','16:30','17:00','18:30','19:00','20:30','21:00','22:30'].map(t =>
                              <option key={t} value={t}>{t}</option>)}
                          </select>
                          {showForm.theaterSlots.length > 1 && (
                            <button type="button"
                              onClick={() => setShowForm(f => ({ ...f, theaterSlots: f.theaterSlots.filter((_, i) => i !== idx) }))}
                              className="p-1.5 text-gray-500 hover:text-red-400 hover:bg-red-900/20 rounded-lg transition-colors shrink-0">
                              <X className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="md:col-span-2 flex gap-3">
                    <button type="submit" className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors">
                      <Save className="w-4 h-4" /> Schedule {showForm.theaterSlots.length > 1 ? `${showForm.theaterSlots.length} Shows` : 'Show'}
                    </button>
                    <button type="button" onClick={() => setShowShowForm(false)}
                      className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors border border-gray-700">
                      <X className="w-4 h-4" /> Cancel
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-800 bg-gray-800/50">
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Movie</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden sm:table-cell">Theater</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Date & Time</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden md:table-cell">Price</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden md:table-cell">Seats</th>
                      <th className="text-right px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {shows.length === 0 && (
                      <tr><td colSpan={6} className="px-4 py-10 text-center text-gray-400">No shows scheduled yet. Click "Schedule Show" to add one.</td></tr>
                    )}
                    {[...shows].sort((a, b) => a.date.localeCompare(b.date)).map(show => {
                      const movie = movies.find(m => m.id === show.movieId);
                      const theater = theaters.find(t => t.id === show.theaterId);
                      const isPast = new Date(`${show.date}T${show.time}`) < new Date();
                      return (
                        <tr key={show.id} className={`hover:bg-gray-800/30 transition-colors ${isPast ? 'opacity-50' : ''}`}>
                          <td className="px-4 py-3">
                            <p className="text-white text-sm font-medium">{movie?.title || 'Unknown'}</p>
                            <p className="text-gray-500 text-xs">{movie?.genre?.slice(0,2).join(', ')}</p>
                          </td>
                          <td className="px-4 py-3 hidden sm:table-cell">
                            <p className="text-gray-300 text-sm">{theater?.name || 'Unknown'}</p>
                            <p className="text-gray-500 text-xs">{theater?.location}</p>
                          </td>
                          <td className="px-4 py-3">
                            <p className="text-white text-sm font-medium">{show.date}</p>
                            <p className="text-gray-400 text-xs">{show.time} {isPast && <span className="text-red-400 ml-1">(Past)</span>}</p>
                          </td>
                          <td className="px-4 py-3 hidden md:table-cell">
                            <span className="text-green-400 font-semibold text-sm">₹{show.price}</span>
                          </td>
                          <td className="px-4 py-3 hidden md:table-cell">
                            <span className="text-gray-300 text-sm">{show.availableSeats.length - show.bookedSeats.length} / {show.availableSeats.length} free</span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center justify-end">
                              <button onClick={() => handleDeleteShow(show.id)} className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-900/20 rounded-lg transition-colors">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* USERS */}
        {tab === 'users' && (
          <div>
            <h2 className="text-lg font-bold text-white mb-4">Registered Users ({users.length})</h2>
            <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-800 bg-gray-800/50">
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">User</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden sm:table-cell">Email</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Role</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden md:table-cell">Joined</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden md:table-cell">Bookings</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {users.map(user => (
                      <tr key={user.id} className="hover:bg-gray-800/30 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                              {user.name.charAt(0).toUpperCase()}
                            </div>
                            <p className="text-white text-sm font-medium">{user.name}</p>
                          </div>
                        </td>
                        <td className="px-4 py-3 hidden sm:table-cell">
                          <span className="text-gray-300 text-sm">{user.email}</span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-1 rounded-full font-semibold ${user.role === 'admin' ? 'bg-yellow-900/40 text-yellow-400' : 'bg-blue-900/40 text-blue-400'}`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          <span className="text-gray-400 text-sm">{new Date(user.createdAt).toLocaleDateString()}</span>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          <span className="text-gray-300 text-sm font-medium">
                            {bookings.filter(b => b.userId === user.id).length}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* BOOKINGS */}
        {tab === 'bookings' && (
          <div>
            <h2 className="text-lg font-bold text-white mb-4">All Bookings ({bookings.length})</h2>
            <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-800 bg-gray-800/50">
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Ref</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Movie</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden sm:table-cell">Seats</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide hidden md:table-cell">Amount</th>
                      <th className="text-left px-4 py-3 text-xs text-gray-400 font-semibold uppercase tracking-wide">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {[...bookings].reverse().slice(0, 50).map(booking => {
                      const movie = movies.find(m => m.id === booking.movieId);
                      return (
                        <tr key={booking.id} className="hover:bg-gray-800/30 transition-colors">
                          <td className="px-4 py-3">
                            <span className="text-xs font-mono text-gray-300 bg-gray-800 px-2 py-1 rounded">{booking.bookingRef}</span>
                          </td>
                          <td className="px-4 py-3">
                            <p className="text-white text-sm font-medium">{movie?.title || 'Unknown'}</p>
                            <p className="text-gray-500 text-xs">{new Date(booking.bookingDate).toLocaleDateString()}</p>
                          </td>
                          <td className="px-4 py-3 hidden sm:table-cell">
                            <div className="flex flex-wrap gap-1">
                              {booking.seats.map(s => <span key={s} className="text-xs bg-gray-800 text-gray-300 px-1.5 py-0.5 rounded font-mono">{s}</span>)}
                            </div>
                          </td>
                          <td className="px-4 py-3 hidden md:table-cell">
                            <span className="text-white font-semibold text-sm">₹{booking.totalAmount}</span>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-1 rounded-full font-semibold ${booking.status === 'confirmed' ? 'bg-green-900/40 text-green-400' : 'bg-red-900/40 text-red-400'}`}>
                              {booking.status}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                    {bookings.length === 0 && (
                      <tr><td colSpan={5} className="px-4 py-10 text-center text-gray-400">No bookings yet</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* THEATERS */}
        {tab === 'theaters' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">Manage Theaters ({theaters.length})</h2>
              <button
                onClick={() => setShowTheaterForm(!showTheaterForm)}
                className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors"
              >
                {showTheaterForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                {showTheaterForm ? 'Cancel' : 'Add Theater'}
              </button>
            </div>

            {showTheaterForm && (
              <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5 mb-6">
                <h3 className="text-white font-bold mb-4">🏛️ Add New Theater</h3>
                <form onSubmit={handleTheaterSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1 font-medium">Theater Name</label>
                    <input type="text" value={theaterForm.name} onChange={e => setTheaterForm(f => ({ ...f, name: e.target.value }))}
                      placeholder="Theater name" required
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500 placeholder-gray-500" />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1 font-medium">Location</label>
                    <input type="text" value={theaterForm.location} onChange={e => setTheaterForm(f => ({ ...f, location: e.target.value }))}
                      placeholder="City, State" required
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500 placeholder-gray-500" />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1 font-medium">Total Seats</label>
                    <input type="number" value={theaterForm.totalSeats} onChange={e => setTheaterForm(f => ({ ...f, totalSeats: Number(e.target.value) }))}
                      min={10} max={500}
                      className="w-full bg-gray-800 border border-gray-700 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500" />
                  </div>
                  <button type="submit" className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors w-fit">
                    <Save className="w-4 h-4" /> Add Theater
                  </button>
                </form>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {theaters.map(theater => (
                <div key={theater.id} className="bg-gray-900 border border-gray-800 rounded-2xl p-5 hover:border-gray-700 transition-colors">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-white font-bold">{theater.name}</h3>
                      <p className="text-gray-400 text-sm mt-0.5">{theater.location}</p>
                      <p className="text-gray-500 text-xs mt-2">{theater.totalSeats} total seats</p>
                    </div>
                    <button onClick={() => { if (confirm('Delete this theater?')) { sbDeleteTheater(theater.id); refresh(); } }}
                      className="p-1.5 text-gray-500 hover:text-red-400 hover:bg-red-900/20 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="mt-4 bg-gray-800 rounded-xl p-3 text-xs font-mono text-gray-400">
                    <span className="text-blue-400">INSERT INTO</span> theaters <span className="text-yellow-400">VALUES</span>('{theater.id}', '{theater.name}', '{theater.location}', {theater.totalSeats});
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="pb-16" />
    </div>
  );
}
