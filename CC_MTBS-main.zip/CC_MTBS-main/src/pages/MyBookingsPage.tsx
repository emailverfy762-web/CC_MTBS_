import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Ticket, Calendar, Clock, MapPin, CheckCircle, XCircle, Film } from 'lucide-react';
import { Booking, User } from '../types';
import { sbGetUserBookings, sbCancelBooking } from '../lib/supabaseDb';

interface MyBookingsPageProps {
  currentUser: User;
}

export default function MyBookingsPage({ currentUser }: MyBookingsPageProps) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [filter, setFilter] = useState<'all' | 'confirmed' | 'cancelled'>('all');
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  useEffect(() => {
    sbGetUserBookings(currentUser.id).then(setBookings);
  }, [currentUser.id]);

  const handleCancel = async (bookingId: string) => {
    if (!confirm('Are you sure you want to cancel this booking?')) return;
    setCancellingId(bookingId);
    await sbCancelBooking(bookingId);
    const updated = await sbGetUserBookings(currentUser.id);
    setBookings(updated);
    setCancellingId(null);
  };

  const filtered = bookings.filter(b => filter === 'all' || b.status === filter);
  const confirmed = bookings.filter(b => b.status === 'confirmed').length;
  const cancelled = bookings.filter(b => b.status === 'cancelled').length;

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-b from-gray-900 to-gray-950 border-b border-gray-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <h1 className="text-3xl font-bold text-white mb-1 flex items-center gap-3">
            <Ticket className="w-8 h-8 text-red-500" /> My Bookings
          </h1>
          <p className="text-gray-400">All your movie ticket bookings</p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-6">
            <div className="bg-gray-800 rounded-xl p-4 text-center border border-gray-700">
              <p className="text-2xl font-bold text-white">{bookings.length}</p>
              <p className="text-gray-400 text-xs mt-1">Total Bookings</p>
            </div>
            <div className="bg-green-900/20 rounded-xl p-4 text-center border border-green-700/30">
              <p className="text-2xl font-bold text-green-400">{confirmed}</p>
              <p className="text-gray-400 text-xs mt-1">Confirmed</p>
            </div>
            <div className="bg-red-900/20 rounded-xl p-4 text-center border border-red-700/30">
              <p className="text-2xl font-bold text-red-400">{cancelled}</p>
              <p className="text-gray-400 text-xs mt-1">Cancelled</p>
            </div>
          </div>

          {/* Filters */}
          <div className="flex gap-2 mt-6">
            {(['all', 'confirmed', 'cancelled'] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors capitalize border ${
                  filter === f ? 'bg-red-600 border-red-600 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:text-white'
                }`}
              >
                {f === 'all' ? `All (${bookings.length})` : f === 'confirmed' ? `Confirmed (${confirmed})` : `Cancelled (${cancelled})`}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bookings List */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <Film className="w-16 h-16 text-gray-700 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-400 mb-2">
              {bookings.length === 0 ? 'No Bookings Yet' : 'No bookings in this category'}
            </h2>
            <p className="text-gray-600 mb-6 text-sm">
              {bookings.length === 0 ? 'Book your first movie ticket now!' : 'Try changing the filter'}
            </p>
            <Link to="/movies" className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-6 py-3 rounded-xl font-semibold transition-colors">
              <Film className="w-4 h-4" /> Browse Movies
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {filtered
              .sort((a, b) => new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime())
              .map(booking => {
                const bk = booking as Booking & { movieTitle?: string; theaterName?: string; showTime?: string; showDate?: string };
                const convFee = Math.round(booking.totalAmount * 0.05);
                const showDateStr = bk.showDate || '';
                const isUpcoming = showDateStr ? new Date(showDateStr + 'T00:00:00') >= new Date(new Date().setHours(0, 0, 0, 0)) : false;

                return (
                  <div
                    key={booking.id}
                    className={`bg-gray-900 rounded-2xl border overflow-hidden transition-all ${
                      booking.status === 'cancelled' ? 'border-gray-800 opacity-70' : 'border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <div className="p-5 flex gap-4">
                      {/* Movie Poster */}
                      <div className="flex-shrink-0">
                        <div className="w-16 rounded-lg border border-gray-700 bg-gray-800 flex items-center justify-center" style={{ height: '88px' }}>
                          <Film className="w-8 h-8 text-gray-600" />
                        </div>
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div>
                            <h3 className="text-white font-bold text-base line-clamp-1">{bk.movieTitle || 'Movie'}</h3>
                            <div className="flex flex-wrap gap-1 mt-1">
                              <span className="text-xs bg-gray-800 text-gray-400 px-2 py-0.5 rounded-full">{bk.theaterName || 'Theater'}</span>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            <span className={`text-xs px-2 py-1 rounded-full font-semibold flex items-center gap-1 ${
                              booking.status === 'confirmed' ? 'bg-green-900/40 text-green-400 border border-green-700/30' : 'bg-red-900/40 text-red-400 border border-red-700/30'
                            }`}>
                              {booking.status === 'confirmed' ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                              {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                            </span>
                            {isUpcoming && booking.status === 'confirmed' && (
                              <span className="text-xs bg-blue-900/40 text-blue-400 border border-blue-700/30 px-2 py-0.5 rounded-full">Upcoming</span>
                            )}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-gray-400 mb-3">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-red-400" />
                            {showDateStr ? new Date(showDateStr + 'T00:00:00').toLocaleDateString('en', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A'}
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-red-400" /> {bk.showTime || 'N/A'}
                          </div>
                          <div className="flex items-center gap-1.5 col-span-2">
                            <MapPin className="w-3.5 h-3.5 text-red-400" /> {bk.theaterName || 'Theater'}
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="flex flex-wrap gap-1.5">
                            <span className="text-gray-400 text-xs">Seats:</span>
                            {booking.seats.map(s => (
                              <span key={s} className="bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-bold px-2 py-0.5 rounded">{s}</span>
                            ))}
                          </div>
                          <div className="text-right">
                            <p className="text-gray-400 text-xs">Total Paid</p>
                            <p className="text-white font-bold text-base">₹{booking.totalAmount + convFee}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Footer */}
                    <div className="px-5 py-3 bg-gray-800/30 border-t border-gray-800 flex items-center justify-between">
                      <p className="text-gray-500 text-xs font-mono">
                        REF: {booking.bookingRef} • {new Date(booking.bookingDate).toLocaleDateString('en', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                      {booking.status === 'confirmed' && isUpcoming && (
                        <button
                          onClick={() => handleCancel(booking.id)}
                          disabled={cancellingId === booking.id}
                          className="text-xs text-red-400 hover:text-red-300 border border-red-700/30 px-3 py-1 rounded-lg transition-colors hover:bg-red-900/20 disabled:opacity-50"
                        >
                          {cancellingId === booking.id ? 'Cancelling...' : 'Cancel Booking'}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        )}
        <div className="pb-16" />
      </div>
    </div>
  );
}
