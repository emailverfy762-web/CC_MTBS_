import { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { Movie } from '../types';
import { sbGetMovies } from '../lib/supabaseDb';
import MovieCard from '../components/MovieCard';

const genres = ['All', 'Action', 'Sci-Fi', 'Drama', 'Comedy', 'Adventure', 'Thriller', 'Animation', 'Biography', 'Fantasy', 'Crime', 'History'];
const statuses = ['All', 'Now Showing', 'Coming Soon'];
const languages = ['All', 'English', 'Hindi', 'Tamil', 'Telugu'];

export default function MoviesPage() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [search, setSearch] = useState('');
  const [genre, setGenre] = useState('All');
  const [status, setStatus] = useState('All');
  const [language, setLanguage] = useState('All');
  const [sortBy, setSortBy] = useState('title');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    sbGetMovies().then(setMovies);
  }, []);

  const filtered = movies
    .filter(m => {
      const matchSearch = m.title.toLowerCase().includes(search.toLowerCase()) || m.director.toLowerCase().includes(search.toLowerCase());
      const matchGenre = genre === 'All' || m.genre.includes(genre);
      const matchStatus = status === 'All' || (status === 'Now Showing' && m.status === 'now_showing') || (status === 'Coming Soon' && m.status === 'coming_soon');
      const matchLang = language === 'All' || m.language === language;
      return matchSearch && matchGenre && matchStatus && matchLang;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.imdbRating - a.imdbRating;
      if (sortBy === 'duration') return b.duration - a.duration;
      return a.title.localeCompare(b.title);
    });

  const clearFilters = () => {
    setSearch(''); setGenre('All'); setStatus('All'); setLanguage('All'); setSortBy('title');
  };

  const hasFilters = search || genre !== 'All' || status !== 'All' || language !== 'All' || sortBy !== 'title';

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-b from-gray-900 to-gray-950 border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <h1 className="text-3xl font-bold text-white mb-1">All Movies</h1>
          <p className="text-gray-400">Browse and book your favorite movies</p>

          {/* Search */}
          <div className="mt-6 flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search movies, directors..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 text-white pl-12 pr-4 py-3 rounded-xl focus:outline-none focus:border-red-500 placeholder-gray-500 transition-colors"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl border transition-colors font-medium text-sm ${showFilters ? 'bg-red-600 border-red-600 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-red-500 hover:text-white'}`}
            >
              <SlidersHorizontal className="w-4 h-4" /> Filters
              {hasFilters && <span className="bg-red-500 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">!</span>}
            </button>
            {hasFilters && (
              <button onClick={clearFilters} className="flex items-center gap-1 px-3 py-3 rounded-xl bg-gray-800 border border-gray-700 text-gray-400 hover:text-white transition-colors text-sm">
                <X className="w-4 h-4" /> Clear
              </button>
            )}
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="mt-4 p-4 bg-gray-800/60 rounded-xl border border-gray-700 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block font-medium uppercase tracking-wide">Genre</label>
                <select
                  value={genre}
                  onChange={e => setGenre(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500"
                >
                  {genres.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block font-medium uppercase tracking-wide">Status</label>
                <select
                  value={status}
                  onChange={e => setStatus(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500"
                >
                  {statuses.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block font-medium uppercase tracking-wide">Language</label>
                <select
                  value={language}
                  onChange={e => setLanguage(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500"
                >
                  {languages.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block font-medium uppercase tracking-wide">Sort By</label>
                <select
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-red-500"
                >
                  <option value="title">Title A-Z</option>
                  <option value="rating">IMDB Rating</option>
                  <option value="duration">Duration</option>
                </select>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Genre Pills */}
      <div className="bg-gray-900 border-b border-gray-800 overflow-x-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex gap-2">
          {genres.slice(0, 8).map(g => (
            <button
              key={g}
              onClick={() => setGenre(g)}
              className={`whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${genre === g ? 'bg-red-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'}`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <p className="text-gray-400 text-sm">
            Showing <span className="text-white font-semibold">{filtered.length}</span> movies
          </p>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">No movies found</p>
            <p className="text-gray-600 text-sm mt-1">Try adjusting your filters</p>
            <button onClick={clearFilters} className="mt-4 text-red-400 hover:text-red-300 text-sm underline">Clear all filters</button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {filtered.map(movie => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
