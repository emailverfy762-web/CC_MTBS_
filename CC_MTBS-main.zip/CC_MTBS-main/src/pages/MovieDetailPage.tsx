import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Star, Clock, Calendar, Globe, User2, Film, ChevronRight, Ticket } from 'lucide-react';
import { Movie, Show, Theater } from '../types';
import { sbGetMovie, sbGetShowsByMovie, sbGetTheaters } from '../lib/supabaseDb';
import { User } from '../types';

interface MovieDetailPageProps {
  currentUser: User | null;
}

export default function MovieDetailPage({ currentUser }: MovieDetailPageProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [shows, setShows] = useState<Show[]>([]);
  const [theaters, setTheaters] = useState<Theater[]>([]);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTheater, setSelectedTheater] = useState('');
  const [dates, setDates] = useState<string[]>([]);

  useEffect(() => {
    if (!id) return;
    Promise.all([sbGetMovie(id), sbGetShowsByMovie(id), sbGetTheaters()]).then(([m, s, t]) => {
      if (!m) { navigate('/movies'); return; }
      setMovie(m);
      setShows(s);
      setTheaters(t);
      const uniqueDates = [...new Set(s.map(sh => sh.date))].sort();
      setDates(uniqueDates);
      if (uniqueDates.length > 0) setSelectedDate(uniqueDates[0]);
    });
  }, [id, navigate]);

  if (!movie) return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin w-10 h-10 border-4 border-red-500 border-t-transparent rounded-full mx-auto mb-4"></div>
        <p className="text-gray-400">Loading movie...</p>
      </div>
    </div>
  );

  const dateShows = shows.filter(s => s.date === selectedDate);
  const theaterIds = [...new Set(dateShows.map(s => s.theaterId))];

  const formatDate = (d: string) => {
    const date = new Date(d + 'T00:00:00');
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
    if (date.toDateString() === today.toDateString()) return { label: 'Today', sub: date.toLocaleDateString('en', { month: 'short', day: 'numeric' }) };
    if (date.toDateString() === tomorrow.toDateString()) return { label: 'Tomorrow', sub: date.toLocaleDateString('en', { month: 'short', day: 'numeric' }) };
    return { label: date.toLocaleDateString('en', { weekday: 'short' }), sub: date.toLocaleDateString('en', { month: 'short', day: 'numeric' }) };
  };

  const handleBookShow = (show: Show) => {
    if (!currentUser) { navigate('/login'); return; }
    navigate(`/movies/${movie.id}/seats`, { state: { show, movie } });
  };

  const getAvailabilityColor = (available: number, total: number) => {
    const pct = available / total;
    if (pct > 0.5) return 'text-green-400';
    if (pct > 0.2) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Banner */}
      <div className="relative h-72 md:h-96">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${movie.bannerUrl})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-black/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent" />

        {/* Breadcrumb */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
          <nav className="flex items-center gap-2 text-sm text-gray-400">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <ChevronRight className="w-4 h-4" />
            <Link to="/movies" className="hover:text-white transition-colors">Movies</Link>
            <ChevronRight className="w-4 h-4" />
            <span className="text-white">{movie.title}</span>
          </nav>
        </div>
      </div>

      {/* Movie Info */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-24 relative z-10">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Poster */}
          <div className="flex-shrink-0">
            <img
              src={movie.posterUrl}
              alt={movie.title}
              className="w-40 md:w-56 rounded-2xl shadow-2xl border-2 border-gray-700 mx-auto md:mx-0"
              onError={(e) => {
                (e.target as HTMLImageElement).src = `https://via.placeholder.com/400x600/1a1a2e/ffffff?text=${encodeURIComponent(movie.title)}`;
              }}
            />
          </div>

          {/* Details */}
          <div className="flex-1 mt-4">
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <span className={`text-xs px-3 py-1 rounded-full font-semibold ${movie.status === 'now_showing' ? 'bg-green-600 text-white' : 'bg-yellow-600 text-white'}`}>
                {movie.status === 'now_showing' ? 'Now Showing' : 'Coming Soon'}
              </span>
              <span className="text-xs border border-gray-600 text-gray-300 px-3 py-1 rounded-full">{movie.rating}</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{movie.title}</h1>
            <div className="flex flex-wrap items-center gap-4 mb-4 text-sm">
              <div className="flex items-center gap-1.5 bg-yellow-500/10 border border-yellow-500/30 px-3 py-1.5 rounded-full">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span className="text-yellow-400 font-bold">{movie.imdbRating}</span>
                <span className="text-gray-400">/10 IMDB</span>
              </div>
              <div className="flex items-center gap-1.5 text-gray-400">
                <Clock className="w-4 h-4" /> <span>{Math.floor(movie.duration / 60)}h {movie.duration % 60}m</span>
              </div>
              <div className="flex items-center gap-1.5 text-gray-400">
                <Calendar className="w-4 h-4" /> <span>{new Date(movie.releaseDate).toLocaleDateString('en', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
              </div>
              <div className="flex items-center gap-1.5 text-gray-400">
                <Globe className="w-4 h-4" /> <span>{movie.language}</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 mb-4">
              {movie.genre.map(g => (
                <span key={g} className="bg-gray-800 border border-gray-700 text-gray-300 text-xs px-3 py-1 rounded-full">{g}</span>
              ))}
            </div>
            <p className="text-gray-300 leading-relaxed mb-4 max-w-2xl">{movie.description}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm max-w-xl">
              <div className="flex items-start gap-2">
                <Film className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                <div><span className="text-gray-400">Director: </span><span className="text-white font-medium">{movie.director}</span></div>
              </div>
              <div className="flex items-start gap-2">
                <User2 className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                <div><span className="text-gray-400">Cast: </span><span className="text-white font-medium">{movie.cast.slice(0, 3).join(', ')}</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* Booking Section */}
        {movie.status === 'now_showing' && (
          <div className="mt-12 bg-gray-900 rounded-2xl border border-gray-800 p-6">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Ticket className="w-5 h-5 text-red-500" /> Book Tickets
            </h2>

            {/* Date Selection */}
            <div className="mb-6">
              <label className="text-sm text-gray-400 mb-3 block font-medium uppercase tracking-wide">Select Date</label>
              <div className="flex gap-3 overflow-x-auto pb-2">
                {dates.slice(0, 7).map(date => {
                  const { label, sub } = formatDate(date);
                  return (
                    <button
                      key={date}
                      onClick={() => setSelectedDate(date)}
                      className={`flex-shrink-0 flex flex-col items-center px-5 py-3 rounded-xl border transition-all ${
                        selectedDate === date
                          ? 'bg-red-600 border-red-600 text-white shadow-lg shadow-red-900/30'
                          : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-red-500 hover:text-white'
                      }`}
                    >
                      <span className="font-bold text-sm">{label}</span>
                      <span className="text-xs opacity-75 mt-0.5">{sub}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Theater Filter */}
            {theaterIds.length > 1 && (
              <div className="mb-6">
                <label className="text-sm text-gray-400 mb-3 block font-medium uppercase tracking-wide">Filter by Theater</label>
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => setSelectedTheater('')}
                    className={`px-4 py-2 rounded-lg text-sm font-medium border transition-colors ${!selectedTheater ? 'bg-red-600 border-red-600 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:text-white'}`}
                  >
                    All Theaters
                  </button>
                  {theaterIds.map(tid => {
                    const t = theaters.find(th => th.id === tid);
                    return t ? (
                      <button
                        key={tid}
                        onClick={() => setSelectedTheater(tid)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium border transition-colors ${selectedTheater === tid ? 'bg-red-600 border-red-600 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:text-white'}`}
                      >
                        {t.name}
                      </button>
                    ) : null;
                  })}
                </div>
              </div>
            )}

            {/* Shows by Theater */}
            <div className="space-y-6">
              {theaterIds
                .filter(tid => !selectedTheater || tid === selectedTheater)
                .map(theaterId => {
                  const theater = theaters.find(th => th.id === theaterId);
                  const theaterShows = dateShows.filter(s => s.theaterId === theaterId);
                  if (!theater || theaterShows.length === 0) return null;
                  return (
                    <div key={theaterId} className="bg-gray-800/50 rounded-xl p-4 border border-gray-700">
                      <div className="flex items-center gap-2 mb-4">
                        <Film className="w-4 h-4 text-red-400" />
                        <h3 className="text-white font-semibold">{theater.name}</h3>
                        <span className="text-gray-400 text-sm">— {theater.location}</span>
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {theaterShows.map(show => {
                          const avail = show.availableSeats.length;
                          const total = avail + show.bookedSeats.length;
                          const isSoldOut = avail === 0;
                          return (
                            <button
                              key={show.id}
                              onClick={() => !isSoldOut && handleBookShow(show)}
                              disabled={isSoldOut}
                              className={`flex flex-col items-center px-5 py-3 rounded-xl border transition-all ${
                                isSoldOut
                                  ? 'bg-gray-700/40 border-gray-700 text-gray-500 cursor-not-allowed'
                                  : 'bg-gray-800 border-gray-600 hover:border-red-500 hover:bg-gray-700 text-white cursor-pointer active:scale-95'
                              }`}
                            >
                              <span className="font-bold text-base">{show.time}</span>
                              <span className="text-xs mt-1 font-semibold text-green-400">₹{show.price}</span>
                              <span className={`text-xs mt-0.5 ${isSoldOut ? 'text-red-500' : getAvailabilityColor(avail, total)}`}>
                                {isSoldOut ? 'Sold Out' : `${avail} seats`}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
            </div>

            {dateShows.length === 0 && (
              <div className="text-center py-10 text-gray-400">
                <Calendar className="w-10 h-10 mx-auto mb-3 opacity-50" />
                <p>No shows available for this date</p>
              </div>
            )}
          </div>
        )}

        {movie.status === 'coming_soon' && (
          <div className="mt-12 bg-yellow-900/20 border border-yellow-700/30 rounded-2xl p-8 text-center">
            <Calendar className="w-12 h-12 text-yellow-500 mx-auto mb-3" />
            <h2 className="text-xl font-bold text-yellow-400 mb-2">Coming Soon</h2>
            <p className="text-gray-400">This movie releases on {new Date(movie.releaseDate).toLocaleDateString('en', { month: 'long', day: 'numeric', year: 'numeric' })}. Booking will open soon!</p>
          </div>
        )}

        <div className="pb-16" />
      </div>
    </div>
  );
}
