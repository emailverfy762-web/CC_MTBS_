import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Movie, Show, User, Booking, Seat } from '../types';
import { sbAddBooking, sbGetShow, sbGetTheater, sbUpdateShow } from '../lib/supabaseDb';
import { Ticket, ChevronLeft, Monitor } from 'lucide-react';

interface SeatSelectionPageProps {
  currentUser: User;
  onBooking: (booking: Booking) => void;
}

const ROWS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
const COLS = 12;

const getSeatType = (row: string): 'recliner' | 'premium' | 'standard' => {
  if (['A', 'B'].includes(row)) return 'recliner';
  if (['C', 'D', 'E'].includes(row)) return 'premium';
  return 'standard';
};

const getSeatPriceMultiplier = (type: string) => {
  if (type === 'recliner') return 1.5;
  if (type === 'premium') return 1.25;
  return 1;
};

export default function SeatSelectionPage({ currentUser, onBooking }: SeatSelectionPageProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as { show: Show; movie: Movie } | null;

  const [show, setShow] = useState<Show | null>(state?.show || null);
  const movie = state?.movie;
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [bookedSeats, setBookedSeats] = useState<string[]>([]);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!state?.show || !state?.movie) {
      navigate('/movies');
      return;
    }
    sbGetShow(state.show.id).then(freshShow => {
      if (freshShow) {
        setShow(freshShow);
        setBookedSeats(freshShow.bookedSeats);
      }
    });
  }, []);

  if (!show || !movie) return null;

  const generateSeats = (): Seat[][] => {
    return ROWS.map(row =>
      Array.from({ length: COLS }, (_, i) => {
        const seatId = `${row}${i + 1}`;
        return {
          id: seatId,
          row,
          number: i + 1,
          type: getSeatType(row),
          isBooked: bookedSeats.includes(seatId),
          isSelected: selectedSeats.includes(seatId),
        };
      })
    );
  };

  const seats = generateSeats();

  const toggleSeat = (seat: Seat) => {
    if (seat.isBooked) return;
    if (selectedSeats.includes(seat.id)) {
      setSelectedSeats(prev => prev.filter(s => s !== seat.id));
    } else {
      if (selectedSeats.length >= 8) {
        alert('You can select maximum 8 seats at once.');
        return;
      }
      setSelectedSeats(prev => [...prev, seat.id]);
    }
  };

  const getSeatColor = (seat: Seat) => {
    if (seat.isBooked)
      return 'bg-gray-700/40 border-gray-600/40 cursor-not-allowed text-gray-600';
    if (seat.isSelected)
      return 'bg-red-600 border-red-400 text-white cursor-pointer scale-105 shadow-lg shadow-red-900/60';
    if (seat.type === 'recliner')
      return 'bg-purple-900/50 border-purple-600 hover:bg-purple-600 hover:border-purple-400 cursor-pointer text-purple-300';
    if (seat.type === 'premium')
      return 'bg-blue-900/50 border-blue-600 hover:bg-blue-600 hover:border-blue-400 cursor-pointer text-blue-300';
    return 'bg-gray-800/80 border-gray-600 hover:bg-gray-600 hover:border-gray-400 cursor-pointer text-gray-300';
  };

  const calcTotal = () => {
    return selectedSeats.reduce((total, seatId) => {
      const row = seatId[0];
      const type = getSeatType(row);
      return total + Math.round(show.price * getSeatPriceMultiplier(type));
    }, 0);
  };

  const handleConfirmBooking = async () => {
    if (selectedSeats.length === 0) return;
    setConfirming(true);

    const bookingRef = 'CB' + Date.now().toString().slice(-8).toUpperCase();
    const booking: Booking = {
      id: 'b' + Date.now(),
      userId: currentUser.id,
      movieId: movie.id,
      showId: show.id,
      theaterId: show.theaterId,
      seats: selectedSeats,
      totalAmount: calcTotal(),
      bookingDate: new Date().toISOString(),
      status: 'confirmed',
      bookingRef,
    };

    const updatedShow: Show = {
      ...show,
      bookedSeats: [...show.bookedSeats, ...selectedSeats],
      availableSeats: show.availableSeats.filter(s => !selectedSeats.includes(s)),
    };
    // Update show seats in Supabase
    await sbUpdateShow(updatedShow);
    // Resolve theater name from Supabase
    const theater = await sbGetTheater(show.theaterId);
    // Save booking to Supabase (cross-device)
    await sbAddBooking({
      ...booking,
      movieTitle: movie.title,
      theaterName: theater?.name || show.theaterId,
      showTime: show.time,
      showDate: show.date,
    });
    onBooking(booking);

    setTimeout(() => {
      navigate('/booking-confirm', { state: { booking, movie, show } });
    }, 500);
  };

  const totalAmount = calcTotal();
  const convFee = Math.round(totalAmount * 0.05);
  const leftCols = Array.from({ length: 6 }, (_, i) => i);
  const rightCols = Array.from({ length: 6 }, (_, i) => i + 6);

  // seat button size in px
  const BTN = 32; // w-8 = 32px
  const GAP = 4;  // gap-1 = 4px
  // total grid width: label(28) + 6 seats + gaps + aisle(20) + 6 seats + gaps + label(28)
  const gridWidth = 28 + (6 * BTN + 5 * GAP) + 20 + (6 * BTN + 5 * GAP) + 28;

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Header */}
      <div className="bg-gray-900 border-b border-gray-800 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-gray-400" />
          </button>
          <div>
            <h1 className="text-white font-bold text-lg">{movie.title}</h1>
            <p className="text-gray-400 text-sm">
              {show.date} &bull; {show.time} &bull; Base Price ₹{show.price}
            </p>
          </div>
        </div>
      </div>

      <div className="py-6 px-4 overflow-x-auto">
        {/* Screen */}
        <div className="mb-6 text-center">
          <div className="relative mx-auto" style={{ width: gridWidth }}>
            <div className="h-2 bg-gradient-to-r from-transparent via-red-500 to-transparent rounded-full blur-sm" />
            <div className="h-1 bg-gradient-to-r from-transparent via-red-400 to-transparent rounded-full" />
          </div>
          <div className="mt-3 flex justify-center">
            <div className="bg-gray-800/80 border border-gray-700 rounded-b-3xl px-12 py-2 flex items-center gap-2">
              <Monitor className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400 text-xs tracking-widest uppercase font-medium">
                All Eyes This Way
              </span>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap justify-center gap-4 mb-6 text-xs">
          {[
            { color: 'bg-gray-800 border-gray-600', label: 'Standard', price: `₹${show.price}` },
            { color: 'bg-blue-900/50 border-blue-600', label: 'Premium', price: `₹${Math.round(show.price * 1.25)}` },
            { color: 'bg-purple-900/50 border-purple-600', label: 'Recliner', price: `₹${Math.round(show.price * 1.5)}` },
            { color: 'bg-red-600 border-red-400', label: 'Selected', price: '' },
            { color: 'bg-gray-700/40 border-gray-600/40 opacity-60', label: 'Booked', price: '' },
          ].map(({ color, label, price }) => (
            <div key={label} className="flex items-center gap-2">
              <div className={`w-6 h-6 rounded-md border ${color}`} />
              <span className="text-gray-400 font-medium">
                {label}{price && <span className="text-gray-500 ml-1">{price}</span>}
              </span>
            </div>
          ))}
        </div>

        {/* ── Main layout: fixed-width seat grid + fixed-width summary ── */}
        <div
          className="mx-auto flex gap-6 items-start"
          style={{ width: gridWidth + 8 + 300 }} /* gridWidth + gap(8) + summary(300) */
        >
          {/* ── Seat Grid (exact pixel width) ── */}
          <div className="flex-shrink-0" style={{ width: gridWidth }}>

            {seats.map((row, rowIdx) => {
              const rowLabel = ROWS[rowIdx];
              const sectionLabel =
                rowLabel === 'A' ? (
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-7" />
                    <span className="text-purple-400 text-xs font-bold uppercase tracking-widest px-2 py-0.5 bg-purple-900/20 border border-purple-800/30 rounded">
                      ★ Recliner — ₹{Math.round(show.price * 1.5)}
                    </span>
                  </div>
                ) : rowLabel === 'C' ? (
                  <div className="flex items-center gap-2 mt-3 mb-1">
                    <div className="w-7" />
                    <span className="text-blue-400 text-xs font-bold uppercase tracking-widest px-2 py-0.5 bg-blue-900/20 border border-blue-800/30 rounded">
                      ★ Premium — ₹{Math.round(show.price * 1.25)}
                    </span>
                  </div>
                ) : rowLabel === 'F' ? (
                  <div className="flex items-center gap-2 mt-3 mb-1">
                    <div className="w-7" />
                    <span className="text-gray-400 text-xs font-bold uppercase tracking-widest px-2 py-0.5 bg-gray-800/60 border border-gray-700/30 rounded">
                      Standard — ₹{show.price}
                    </span>
                  </div>
                ) : null;

              return (
                <div key={rowLabel}>
                  {sectionLabel}
                  <div className="flex items-center gap-1 mb-1">
                    {/* Row label left */}
                    <div className="w-7 text-center text-xs text-gray-500 font-bold flex-shrink-0">
                      {rowLabel}
                    </div>
                    {/* Left 6 seats */}
                    <div className="flex gap-1">
                      {leftCols.map(colIdx => {
                        const seat = row[colIdx];
                        return (
                          <button
                            key={seat.id}
                            onClick={() => toggleSeat(seat)}
                            disabled={seat.isBooked}
                            style={{ width: BTN, height: BTN }}
                            className={`rounded-md border text-xs font-bold transition-all duration-150 flex items-center justify-center flex-shrink-0 ${getSeatColor(seat)}`}
                            title={`${seat.id} — ${seat.type} — ₹${Math.round(show.price * getSeatPriceMultiplier(seat.type))}`}
                          >
                            {seat.isBooked ? '×' : seat.number}
                          </button>
                        );
                      })}
                    </div>
                    {/* Aisle */}
                    <div className="flex-shrink-0 flex items-center justify-center" style={{ width: 20 }}>
                      <div className="border-l border-dashed border-gray-700/60" style={{ height: BTN }} />
                    </div>
                    {/* Right 6 seats */}
                    <div className="flex gap-1">
                      {rightCols.map(colIdx => {
                        const seat = row[colIdx];
                        return (
                          <button
                            key={seat.id}
                            onClick={() => toggleSeat(seat)}
                            disabled={seat.isBooked}
                            style={{ width: BTN, height: BTN }}
                            className={`rounded-md border text-xs font-bold transition-all duration-150 flex items-center justify-center flex-shrink-0 ${getSeatColor(seat)}`}
                            title={`${seat.id} — ${seat.type} — ₹${Math.round(show.price * getSeatPriceMultiplier(seat.type))}`}
                          >
                            {seat.isBooked ? '×' : seat.number}
                          </button>
                        );
                      })}
                    </div>
                    {/* Row label right */}
                    <div className="w-7 text-center text-xs text-gray-500 font-bold flex-shrink-0">
                      {rowLabel}
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Column numbers bottom */}
            <div className="flex items-center gap-1 mt-2">
              <div style={{ width: 28 }} />
              <div className="flex gap-1">
                {leftCols.map(i => (
                  <div key={i} style={{ width: BTN }} className="text-center text-xs text-gray-600 font-medium flex-shrink-0">
                    {i + 1}
                  </div>
                ))}
              </div>
              <div style={{ width: 20 }} />
              <div className="flex gap-1">
                {rightCols.map(i => (
                  <div key={i} style={{ width: BTN }} className="text-center text-xs text-gray-600 font-medium flex-shrink-0">
                    {i + 1}
                  </div>
                ))}
              </div>
            </div>

            {/* Seat stats */}
            <div className="mt-4 flex justify-center gap-8 text-xs text-gray-500">
              <span>Total: {ROWS.length * COLS}</span>
              <span className="text-red-400">Booked: {bookedSeats.length}</span>
              <span className="text-green-400">Available: {ROWS.length * COLS - bookedSeats.length}</span>
            </div>
          </div>

          {/* ── Booking Summary (exact 300px wide) ── */}
          <div className="flex-shrink-0" style={{ width: 300 }}>
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-5 flex flex-col">
              <h2 className="text-base font-bold text-white mb-1 flex items-center gap-2">
                <Ticket className="w-5 h-5 text-red-500" />
                Booking Summary
              </h2>
              <p className="text-gray-500 text-xs mb-4">
                {movie.title} • {show.time}
              </p>

              {selectedSeats.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10">
                  <div className="text-5xl mb-3">🎟️</div>
                  <p className="text-gray-400 text-sm text-center">
                    Select seats from<br />the grid to continue
                  </p>
                </div>
              ) : (
                <div className="flex flex-col">
                  {/* Selected seat chips */}
                  <div className="flex flex-wrap gap-2 mb-4 max-h-48 overflow-y-auto">
                    {selectedSeats.map(seatId => {
                      const row = seatId[0];
                      const type = getSeatType(row);
                      const price = Math.round(show.price * getSeatPriceMultiplier(type));
                      return (
                        <div
                          key={seatId}
                          className="flex items-center gap-1.5 bg-red-600/20 border border-red-500/30 px-2 py-1 rounded-lg"
                        >
                          <span className="text-white font-semibold text-xs">{seatId}</span>
                          <span className="text-red-300 text-xs capitalize">{type}</span>
                          <span className="text-red-400 text-xs font-bold">₹{price}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Price breakdown */}
                  <div className="border-t border-gray-800 pt-4 space-y-2 text-sm">
                    <div className="flex justify-between text-gray-300">
                      <span>{selectedSeats.length} Ticket(s)</span>
                      <span>₹{totalAmount}</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Convenience Fee (5%)</span>
                      <span>₹{convFee}</span>
                    </div>
                    <div className="flex justify-between text-white font-bold text-base border-t border-gray-700 pt-3 mt-1">
                      <span>Total</span>
                      <span className="text-red-400">₹{totalAmount + convFee}</span>
                    </div>
                  </div>

                  <button
                    onClick={handleConfirmBooking}
                    disabled={confirming}
                    className="w-full mt-4 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white py-3 rounded-xl font-bold text-sm transition-all hover:shadow-lg hover:shadow-red-900/50 flex items-center justify-center gap-2"
                  >
                    {confirming ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                        Confirming...
                      </>
                    ) : (
                      <>
                        <Ticket className="w-4 h-4" />
                        Confirm — ₹{totalAmount + convFee}
                      </>
                    )}
                  </button>
                  <p className="text-gray-600 text-xs text-center mt-2">
                    Max 8 seats per booking
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="pb-12" />
      </div>
    </div>
  );
}
