import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://emqfldnxsyyctlzsdywl.supabase.co';
const supabaseKey = 'sb_publishable_cjvz7h_Awwc73XOzArfINg_x_mdHfQP';

export const supabase = createClient(supabaseUrl, supabaseKey);
