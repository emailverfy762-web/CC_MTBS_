import { supabase } from './supabase';
import { User, Booking, Movie, Theater, Show } from '../types';

// ─── MOVIE FUNCTIONS ──────────────────────────────────────────────────────────

export const sbGetMovies = async (): Promise<Movie[]> => {
  const { data, error } = await supabase.from('movies').select('*').order('created_at', { ascending: true });
  if (error) { console.error('sbGetMovies error:', error); return []; }
  return (data || []).map(m => ({
    id: m.id,
    title: m.title,
    genre: m.genre,
    language: m.language,
    duration: m.duration,
    rating: m.rating,
    imdbRating: m.imdb_rating,
    description: m.description,
    posterUrl: m.poster_url,
    bannerUrl: m.banner_url,
    releaseDate: m.release_date,
    cast: m.cast,
    director: m.director,
    status: m.status as Movie['status'],
  }));
};

export const sbGetMovie = async (id: string): Promise<Movie | null> => {
  const { data, error } = await supabase.from('movies').select('*').eq('id', id).single();
  if (error || !data) return null;
  return {
    id: data.id,
    title: data.title,
    genre: data.genre,
    language: data.language,
    duration: data.duration,
    rating: data.rating,
    imdbRating: data.imdb_rating,
    description: data.description,
    posterUrl: data.poster_url,
    bannerUrl: data.banner_url,
    releaseDate: data.release_date,
    cast: data.cast,
    director: data.director,
    status: data.status as Movie['status'],
  };
};

export const sbAddMovie = async (movie: Movie): Promise<boolean> => {
  const { error } = await supabase.from('movies').insert({
    id: movie.id,
    title: movie.title,
    genre: movie.genre,
    language: movie.language,
    duration: movie.duration,
    rating: movie.rating,
    imdb_rating: movie.imdbRating,
    description: movie.description,
    poster_url: movie.posterUrl,
    banner_url: movie.bannerUrl,
    release_date: movie.releaseDate,
    cast: movie.cast,
    director: movie.director,
    status: movie.status,
  });
  if (error) { console.error('sbAddMovie error:', error); return false; }
  return true;
};

export const sbUpdateMovie = async (movie: Movie): Promise<boolean> => {
  const { error } = await supabase.from('movies').update({
    title: movie.title,
    genre: movie.genre,
    language: movie.language,
    duration: movie.duration,
    rating: movie.rating,
    imdb_rating: movie.imdbRating,
    description: movie.description,
    poster_url: movie.posterUrl,
    banner_url: movie.bannerUrl,
    release_date: movie.releaseDate,
    cast: movie.cast,
    director: movie.director,
    status: movie.status,
  }).eq('id', movie.id);
  if (error) { console.error('sbUpdateMovie error:', error); return false; }
  return true;
};

export const sbDeleteMovie = async (id: string): Promise<boolean> => {
  const { error } = await supabase.from('movies').delete().eq('id', id);
  if (error) { console.error('sbDeleteMovie error:', error); return false; }
  return true;
};

// ─── THEATER FUNCTIONS ────────────────────────────────────────────────────────

export const sbGetTheaters = async (): Promise<Theater[]> => {
  const { data, error } = await supabase.from('theaters').select('*').order('created_at', { ascending: true });
  if (error) { console.error('sbGetTheaters error:', error); return []; }
  return (data || []).map(t => ({
    id: t.id,
    name: t.name,
    location: t.location,
    totalSeats: t.total_seats,
  }));
};

export const sbGetTheater = async (id: string): Promise<Theater | null> => {
  const { data, error } = await supabase.from('theaters').select('*').eq('id', id).single();
  if (error || !data) return null;
  return { id: data.id, name: data.name, location: data.location, totalSeats: data.total_seats };
};

export const sbAddTheater = async (theater: Theater): Promise<boolean> => {
  const { error } = await supabase.from('theaters').insert({
    id: theater.id,
    name: theater.name,
    location: theater.location,
    total_seats: theater.totalSeats,
  });
  if (error) { console.error('sbAddTheater error:', error); return false; }
  return true;
};

export const sbDeleteTheater = async (id: string): Promise<boolean> => {
  const { error } = await supabase.from('theaters').delete().eq('id', id);
  if (error) { console.error('sbDeleteTheater error:', error); return false; }
  return true;
};

// ─── SHOW FUNCTIONS ───────────────────────────────────────────────────────────

export const sbGetShows = async (): Promise<Show[]> => {
  const { data, error } = await supabase.from('shows').select('*');
  if (error) { console.error('sbGetShows error:', error); return []; }
  return (data || []).map(s => ({
    id: s.id,
    movieId: s.movie_id,
    theaterId: s.theater_id,
    date: s.date,
    time: s.time,
    price: s.price,
    availableSeats: s.available_seats,
    bookedSeats: s.booked_seats,
  }));
};

export const sbGetShow = async (id: string): Promise<Show | null> => {
  const { data, error } = await supabase.from('shows').select('*').eq('id', id).single();
  if (error || !data) return null;
  return {
    id: data.id,
    movieId: data.movie_id,
    theaterId: data.theater_id,
    date: data.date,
    time: data.time,
    price: data.price,
    availableSeats: data.available_seats,
    bookedSeats: data.booked_seats,
  };
};

export const sbGetShowsByMovie = async (movieId: string): Promise<Show[]> => {
  const { data, error } = await supabase.from('shows').select('*').eq('movie_id', movieId);
  if (error) { console.error('sbGetShowsByMovie error:', error); return []; }
  return (data || []).map(s => ({
    id: s.id,
    movieId: s.movie_id,
    theaterId: s.theater_id,
    date: s.date,
    time: s.time,
    price: s.price,
    availableSeats: s.available_seats,
    bookedSeats: s.booked_seats,
  }));
};

export const sbUpdateShow = async (show: Show): Promise<boolean> => {
  const { error } = await supabase.from('shows').update({
    available_seats: show.availableSeats,
    booked_seats: show.bookedSeats,
  }).eq('id', show.id);
  if (error) { console.error('sbUpdateShow error:', error); return false; }
  return true;
};

export const sbAddShow = async (show: Show): Promise<boolean> => {
  const { error } = await supabase.from('shows').insert({
    id: show.id,
    movie_id: show.movieId,
    theater_id: show.theaterId,
    date: show.date,
    time: show.time,
    price: show.price,
    available_seats: show.availableSeats,
    booked_seats: show.bookedSeats,
  });
  if (error) { console.error('sbAddShow error:', error); return false; }
  return true;
};

// ─── USER FUNCTIONS ────────────────────────────────────────────────────────────

export const sbGetUsers = async (): Promise<User[]> => {
  const { data, error } = await supabase.from('users').select('*');
  if (error) { console.error('sbGetUsers error:', error); return []; }
  return (data || []).map(u => ({
    id: u.id,
    name: u.name,
    email: u.email,
    password: u.password,
    role: u.role as 'user' | 'admin',
    createdAt: u.created_at,
  }));
};

export const sbFindUserByEmail = async (email: string): Promise<User | null> => {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('email', email)
    .single();
  if (error || !data) return null;
  return {
    id: data.id,
    name: data.name,
    email: data.email,
    password: data.password,
    role: data.role as 'user' | 'admin',
    createdAt: data.created_at,
  };
};

export const sbAddUser = async (user: User): Promise<boolean> => {
  const { error } = await supabase.from('users').insert({
    id: user.id,
    name: user.name,
    email: user.email,
    password: user.password,
    role: user.role,
  });
  if (error) { console.error('sbAddUser error:', error); return false; }
  return true;
};

// ─── BOOKING FUNCTIONS ────────────────────────────────────────────────────────

export const sbGetBookings = async (): Promise<Booking[]> => {
  const { data, error } = await supabase.from('bookings').select('*').order('created_at', { ascending: false });
  if (error) { console.error('sbGetBookings error:', error); return []; }
  return (data || []).map(b => ({
    id: b.id,
    userId: b.user_id,
    movieId: b.movie_id,
    showId: b.show_id,
    theaterId: b.theater_id,
    seats: b.seats,
    totalAmount: b.total_amount,
    bookingDate: b.booking_date,
    status: b.status as 'confirmed' | 'cancelled',
    bookingRef: b.booking_ref,
    movieTitle: b.movie_title,
    theaterName: b.theater_name,
    showTime: b.show_time,
    showDate: b.show_date,
  }));
};

export const sbGetUserBookings = async (userId: string): Promise<Booking[]> => {
  const { data, error } = await supabase
    .from('bookings')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) { console.error('sbGetUserBookings error:', error); return []; }
  return (data || []).map(b => ({
    id: b.id,
    userId: b.user_id,
    movieId: b.movie_id,
    showId: b.show_id,
    theaterId: b.theater_id,
    seats: b.seats,
    totalAmount: b.total_amount,
    bookingDate: b.booking_date,
    status: b.status as 'confirmed' | 'cancelled',
    bookingRef: b.booking_ref,
    movieTitle: b.movie_title,
    theaterName: b.theater_name,
    showTime: b.show_time,
    showDate: b.show_date,
  }));
};

export const sbAddBooking = async (booking: Booking & {
  movieTitle?: string;
  theaterName?: string;
  showTime?: string;
  showDate?: string;
}): Promise<boolean> => {
  const { error } = await supabase.from('bookings').insert({
    id: booking.id,
    user_id: booking.userId,
    movie_id: booking.movieId,
    show_id: booking.showId,
    theater_id: booking.theaterId,
    seats: booking.seats,
    total_amount: booking.totalAmount,
    booking_date: booking.bookingDate,
    status: booking.status,
    booking_ref: booking.bookingRef,
    movie_title: booking.movieTitle || '',
    theater_name: booking.theaterName || '',
    show_time: booking.showTime || '',
    show_date: booking.showDate || '',
  });
  if (error) { console.error('sbAddBooking error:', error); return false; }
  return true;
};

export const sbCancelBooking = async (bookingId: string): Promise<boolean> => {
  const { error } = await supabase
    .from('bookings')
    .update({ status: 'cancelled' })
    .eq('id', bookingId);
  if (error) { console.error('sbCancelBooking error:', error); return false; }
  return true;
};
