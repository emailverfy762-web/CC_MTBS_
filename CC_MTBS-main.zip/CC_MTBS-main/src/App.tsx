import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import HomePage from './pages/HomePage';
import MoviesPage from './pages/MoviesPage';
import MovieDetailPage from './pages/MovieDetailPage';
import SeatSelectionPage from './pages/SeatSelectionPage';
import BookingConfirmPage from './pages/BookingConfirmPage';
import MyBookingsPage from './pages/MyBookingsPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import AdminPage from './pages/AdminPage';

import Navbar from './components/Navbar';
import { User } from './types';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('cc_user');
    if (stored) {
      try { setCurrentUser(JSON.parse(stored)); } catch { localStorage.removeItem('cc_user'); }
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('cc_user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('cc_user');
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-950 text-white">
        <Navbar currentUser={currentUser} onLogout={handleLogout} />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/movies" element={<MoviesPage />} />
          <Route path="/movies/:id" element={<MovieDetailPage currentUser={currentUser} />} />
          <Route
            path="/movies/:id/seats"
            element={
              currentUser ? (
                <SeatSelectionPage currentUser={currentUser} onBooking={() => {}} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/booking-confirm"
            element={currentUser ? <BookingConfirmPage /> : <Navigate to="/login" />}
          />
          <Route
            path="/my-bookings"
            element={
              currentUser ? (
                <MyBookingsPage currentUser={currentUser} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route path="/login" element={<LoginPage onLogin={handleLogin} />} />
          <Route path="/register" element={<RegisterPage onLogin={handleLogin} />} />
          <Route
            path="/admin"
            element={
              currentUser?.role === 'admin' ? (
                <AdminPage />
              ) : (
                <Navigate to="/" />
              )
            }
          />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
