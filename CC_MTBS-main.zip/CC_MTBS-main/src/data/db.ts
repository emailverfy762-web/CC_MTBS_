import { User, Movie, Theater, Show, Booking } from '../types';

// ─── MYSQL SCHEMA (for reference) ────────────────────────────────────────────
// This app simulates a MySQL database using localStorage.
// MySQL connection config: host=localhost, user=root, password='', database=cinebook
//
// CREATE TABLE users (id VARCHAR(36) PRIMARY KEY, name VARCHAR(100), email VARCHAR(100) UNIQUE,
//   password VARCHAR(255), role ENUM('user','admin'), createdAt DATETIME);
// CREATE TABLE movies (id VARCHAR(36) PRIMARY KEY, title VARCHAR(200), genre JSON, language VARCHAR(50),
//   duration INT, rating VARCHAR(10), imdbRating DECIMAL(3,1), description TEXT,
//   posterUrl TEXT, bannerUrl TEXT, releaseDate DATE, cast JSON, director VARCHAR(100),
//   status ENUM('now_showing','coming_soon','ended'));
// CREATE TABLE theaters (id VARCHAR(36) PRIMARY KEY, name VARCHAR(100), location VARCHAR(200), totalSeats INT);
// CREATE TABLE shows (id VARCHAR(36) PRIMARY KEY, movieId VARCHAR(36), theaterId VARCHAR(36),
//   date DATE, time VARCHAR(10), price DECIMAL(10,2), availableSeats JSON, bookedSeats JSON);
// CREATE TABLE bookings (id VARCHAR(36) PRIMARY KEY, userId VARCHAR(36), movieId VARCHAR(36),
//   showId VARCHAR(36), theaterId VARCHAR(36), seats JSON, totalAmount DECIMAL(10,2),
//   bookingDate DATETIME, status ENUM('confirmed','cancelled'), bookingRef VARCHAR(20));
// ──────────────────────────────────────────────────────────────────────────────

const DB_VERSION = 'cc_v2'; // bump this to reset localStorage
const VERSION_KEY = 'cc_db_version';
const MOVIES_KEY = 'cc_movies';
const USERS_KEY = 'cc_users';
const THEATERS_KEY = 'cc_theaters';
const SHOWS_KEY = 'cc_shows';
const BOOKINGS_KEY = 'cc_bookings';

// ─── DEFAULT DATA ─────────────────────────────────────────────────────────────

const defaultMovies: Movie[] = [
  {
    id: 'm1',
    title: 'Avatar: The Way of Water',
    genre: ['Action', 'Sci-Fi', 'Adventure'],
    language: 'English',
    duration: 192,
    rating: 'PG-13',
    imdbRating: 7.6,
    description: 'Jake Sully lives with his newfound family formed on the extrasolar moon Pandora. Once a familiar threat returns to finish what was previously started, Jake must work with Neytiri and the army of the Na\'vi race to protect their home.',
    posterUrl: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&h=600&fit=crop',
    bannerUrl: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=1200&h=400&fit=crop',
    releaseDate: '2022-12-16',
    cast: ['Sam Worthington', 'Zoe Saldana', 'Sigourney Weaver', 'Stephen Lang'],
    director: 'James Cameron',
    status: 'now_showing',
  },
  {
    id: 'm2',
    title: 'Oppenheimer',
    genre: ['Biography', 'Drama', 'History'],
    language: 'English',
    duration: 180,
    rating: 'R',
    imdbRating: 8.9,
    description: 'The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb during World War II.',
    posterUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop',
    bannerUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&h=400&fit=crop',
    releaseDate: '2023-07-21',
    cast: ['Cillian Murphy', 'Emily Blunt', 'Matt Damon', 'Robert Downey Jr.'],
    director: 'Christopher Nolan',
    status: 'now_showing',
  },
  {
    id: 'm3',
    title: 'Guardians of the Galaxy Vol. 3',
    genre: ['Action', 'Comedy', 'Sci-Fi'],
    language: 'English',
    duration: 150,
    rating: 'PG-13',
    imdbRating: 7.9,
    description: "Still reeling from the loss of Gamora, Peter Quill rallies his team to defend the universe and protect one of their own. A mission that, if not completed successfully, could quite possibly lead to the end of the Guardians as we know them.",
    posterUrl: 'https://images.unsplash.com/photo-1635805737707-575885ab0820?w=400&h=600&fit=crop',
    bannerUrl: 'https://images.unsplash.com/photo-1635805737707-575885ab0820?w=1200&h=400&fit=crop',
    releaseDate: '2023-05-05',
    cast: ['Chris Pratt', 'Zoe Saldana', 'Dave Bautista', 'Bradley Cooper'],
    director: 'James Gunn',
    status: 'now_showing',
  },
  {
    id: 'm4',
    title: 'The Batman',
    genre: ['Action', 'Crime', 'Drama'],
    language: 'English',
    duration: 176,
    rating: 'PG-13',
    imdbRating: 7.8,
    description: 'When the Riddler, a sadistic serial killer, begins murdering key political figures in Gotham, Batman is forced to investigate the city\'s hidden corruption and question his family\'s involvement.',
    posterUrl: 'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=400&h=600&fit=crop',
    bannerUrl: 'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=1200&h=400&fit=crop',
    releaseDate: '2022-03-04',
    cast: ['Robert Pattinson', 'Zoë Kravitz', 'Jeffrey Wright', 'Colin Farrell'],
    director: 'Matt Reeves',
    status: 'now_showing',
  },
  {
    id: 'm5',
    title: 'Dune: Part Two',
    genre: ['Sci-Fi', 'Adventure', 'Drama'],
    language: 'English',
    duration: 166,
    rating: 'PG-13',
    imdbRating: 8.5,
    description: 'Paul Atreides unites with Chani and the Fremen while on a warpath of revenge against the conspirators who destroyed his family.',
    posterUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&h=600&fit=crop',
    bannerUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1200&h=400&fit=crop',
    releaseDate: '2024-03-01',
    cast: ['Timothée Chalamet', 'Zendaya', 'Rebecca Ferguson', 'Josh Brolin'],
    director: 'Denis Villeneuve',
    status: 'now_showing',
  },
  {
    id: 'm6',
    title: 'Spider-Man: Across the Spider-Verse',
    genre: ['Animation', 'Action', 'Adventure'],
    language: 'English',
    duration: 140,
    rating: 'PG',
    imdbRating: 8.7,
    description: 'Miles Morales catapults across the Multiverse, where he encounters a team of Spider-People charged with protecting its very existence.',
    posterUrl: 'https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=400&h=600&fit=crop',
    bannerUrl: 'https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=1200&h=400&fit=crop',
    releaseDate: '2023-06-02',
    cast: ['Shameik Moore', 'Hailee Steinfeld', 'Oscar Isaac', 'Jake Johnson'],
    director: 'Joaquim Dos Santos',
    status: 'now_showing',
  },
  {
    id: 'm7',
    title: 'Mission: Impossible – Dead Reckoning',
    genre: ['Action', 'Adventure', 'Thriller'],
    language: 'English',
    duration: 163,
    rating: 'PG-13',
    imdbRating: 7.7,
    description: 'Ethan Hunt and his IMF team must track down a dangerous weapon before it falls into the wrong hands.',
    posterUrl: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&h=600&fit=crop',
    bannerUrl: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200&h=400&fit=crop',
    releaseDate: '2023-07-12',
    cast: ['Tom Cruise', 'Hayley Atwell', 'Ving Rhames', 'Simon Pegg'],
    director: 'Christopher McQuarrie',
    status: 'coming_soon',
  },
  {
    id: 'm8',
    title: 'Aquaman and the Lost Kingdom',
    genre: ['Action', 'Adventure', 'Fantasy'],
    language: 'English',
    duration: 124,
    rating: 'PG-13',
    imdbRating: 5.4,
    description: 'Black Manta seeks revenge on Aquaman for his father\'s death. Aquaman must forge an alliance with his imprisoned brother to save Atlantis.',
    posterUrl: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&h=600&fit=crop',
    bannerUrl: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=1200&h=400&fit=crop',
    releaseDate: '2023-12-22',
    cast: ['Jason Momoa', 'Patrick Wilson', 'Amber Heard', 'Yahya Abdul-Mateen II'],
    director: 'James Wan',
    status: 'coming_soon',
  },
];

const defaultTheaters: Theater[] = [
  { id: 't1', name: 'CC IMAX', location: 'Downtown, Chennai', totalSeats: 60 },
  { id: 't2', name: 'Galaxy Multiplex', location: 'Velachery, Chennai', totalSeats: 60 },
  { id: 't3', name: 'PVR Cinemas', location: 'Nungambakkam, Chennai', totalSeats: 60 },
];

const generateAllSeats = (): string[] => {
  const seats: string[] = [];
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
  rows.forEach(row => {
    for (let i = 1; i <= 6; i++) {
      seats.push(`${row}${i}`);
    }
  });
  return seats;
};

const generateShows = (): Show[] => {
  const shows: Show[] = [];
  const times = ['10:00 AM', '01:00 PM', '04:00 PM', '07:00 PM', '10:00 PM'];
  const today = new Date();
  let showIdx = 1;

  defaultMovies.forEach(movie => {
    defaultTheaters.forEach(theater => {
      times.forEach(time => {
        for (let d = 0; d < 5; d++) {
          const date = new Date(today);
          date.setDate(today.getDate() + d);
          const dateStr = date.toISOString().split('T')[0];
          const allSeats = generateAllSeats();
          const bookedCount = Math.floor(Math.random() * 20);
          const bookedSeats = allSeats.slice(0, bookedCount);
          const availableSeats = allSeats.slice(bookedCount);
          shows.push({
            id: `s${showIdx++}`,
            movieId: movie.id,
            theaterId: theater.id,
            date: dateStr,
            time,
            price: movie.genre.includes('IMAX') ? 350 : [200, 250, 300][Math.floor(Math.random() * 3)],
            availableSeats,
            bookedSeats,
          });
        }
      });
    });
  });
  return shows;
};

const defaultUsers: User[] = [
  {
    id: 'u1',
    name: 'Admin User',
    email: 'admin@cc.com',
    password: 'admin123',
    role: 'admin',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'u2',
    name: 'John Doe',
    email: 'john@cc.com',
    password: 'john123',
    role: 'user',
    createdAt: new Date().toISOString(),
  },
];

// ─── DB FUNCTIONS ─────────────────────────────────────────────────────────────

function initDB() {
  // If DB version changed, wipe old keys and reseed fresh data
  if (localStorage.getItem(VERSION_KEY) !== DB_VERSION) {
    // Clear all old cinebook_* keys too
    Object.keys(localStorage)
      .filter(k => k.startsWith('cinebook_') || k.startsWith('cc_'))
      .forEach(k => localStorage.removeItem(k));
    localStorage.setItem(VERSION_KEY, DB_VERSION);
  }

  if (!localStorage.getItem(MOVIES_KEY)) {
    localStorage.setItem(MOVIES_KEY, JSON.stringify(defaultMovies));
  }
  if (!localStorage.getItem(USERS_KEY)) {
    localStorage.setItem(USERS_KEY, JSON.stringify(defaultUsers));
  }
  if (!localStorage.getItem(THEATERS_KEY)) {
    localStorage.setItem(THEATERS_KEY, JSON.stringify(defaultTheaters));
  }
  if (!localStorage.getItem(SHOWS_KEY)) {
    localStorage.setItem(SHOWS_KEY, JSON.stringify(generateShows()));
  }
  if (!localStorage.getItem(BOOKINGS_KEY)) {
    localStorage.setItem(BOOKINGS_KEY, JSON.stringify([]));
  }
}

initDB();

export const getMovies = (): Movie[] => JSON.parse(localStorage.getItem(MOVIES_KEY) || '[]');
export const getMovie = (id: string): Movie | undefined => getMovies().find(m => m.id === id);
export const saveMovies = (movies: Movie[]) => localStorage.setItem(MOVIES_KEY, JSON.stringify(movies));
export const addMovie = (movie: Movie) => saveMovies([...getMovies(), movie]);
export const updateMovie = (movie: Movie) => saveMovies(getMovies().map(m => m.id === movie.id ? movie : m));
export const deleteMovie = (id: string) => saveMovies(getMovies().filter(m => m.id !== id));

export const getUsers = (): User[] => JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
export const saveUsers = (users: User[]) => localStorage.setItem(USERS_KEY, JSON.stringify(users));
export const addUser = (user: User) => saveUsers([...getUsers(), user]);
export const findUserByEmail = (email: string): User | undefined => getUsers().find(u => u.email === email);

export const getTheaters = (): Theater[] => JSON.parse(localStorage.getItem(THEATERS_KEY) || '[]');
export const getTheater = (id: string): Theater | undefined => getTheaters().find(t => t.id === id);
export const saveTheaters = (theaters: Theater[]) => localStorage.setItem(THEATERS_KEY, JSON.stringify(theaters));
export const addTheater = (theater: Theater) => saveTheaters([...getTheaters(), theater]);
export const deleteTheater = (id: string) => saveTheaters(getTheaters().filter(t => t.id !== id));

export const getShows = (): Show[] => JSON.parse(localStorage.getItem(SHOWS_KEY) || '[]');
export const getShow = (id: string): Show | undefined => getShows().find(s => s.id === id);
export const getShowsByMovie = (movieId: string): Show[] => getShows().filter(s => s.movieId === movieId);
export const saveShows = (shows: Show[]) => localStorage.setItem(SHOWS_KEY, JSON.stringify(shows));
export const updateShow = (show: Show) => saveShows(getShows().map(s => s.id === show.id ? show : s));

export const getBookings = (): Booking[] => JSON.parse(localStorage.getItem(BOOKINGS_KEY) || '[]');
export const saveBookings = (bookings: Booking[]) => localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
export const addBooking = (booking: Booking) => saveBookings([...getBookings(), booking]);
export const getUserBookings = (userId: string): Booking[] => getBookings().filter(b => b.userId === userId);
export const cancelBooking = (bookingId: string) => {
  const bookings = getBookings().map(b => b.id === bookingId ? { ...b, status: 'cancelled' as const } : b);
  saveBookings(bookings);
};
