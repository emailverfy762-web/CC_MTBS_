export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'user' | 'admin';
  createdAt: string;
}

export interface Movie {
  id: string;
  title: string;
  genre: string[];
  language: string;
  duration: number; // minutes
  rating: string;
  imdbRating: number;
  description: string;
  posterUrl: string;
  bannerUrl: string;
  releaseDate: string;
  cast: string[];
  director: string;
  status: 'now_showing' | 'coming_soon' | 'ended';
}

export interface Theater {
  id: string;
  name: string;
  location: string;
  totalSeats: number;
}

export interface Show {
  id: string;
  movieId: string;
  theaterId: string;
  date: string;
  time: string;
  price: number;
  availableSeats: string[];
  bookedSeats: string[];
}

export interface Booking {
  id: string;
  userId: string;
  movieId: string;
  showId: string;
  theaterId: string;
  seats: string[];
  totalAmount: number;
  bookingDate: string;
  status: 'confirmed' | 'cancelled';
  bookingRef: string;
}

export interface SeatRow {
  row: string;
  seats: Seat[];
}

export interface Seat {
  id: string;
  row: string;
  number: number;
  type: 'standard' | 'premium' | 'recliner';
  isBooked: boolean;
  isSelected: boolean;
}
