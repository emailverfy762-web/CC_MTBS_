import { Link } from 'react-router-dom';
import { Star, Clock, Play } from 'lucide-react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
}

export default function MovieCard({ movie }: MovieCardProps) {
  return (
    <Link to={`/movies/${movie.id}`} className="group block">
      <div className="bg-gray-900 rounded-xl overflow-hidden border border-gray-800 hover:border-red-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-red-900/20 hover:-translate-y-1">
        <div className="relative overflow-hidden aspect-[2/3]">
          <img
            src={movie.posterUrl}
            alt={movie.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            onError={(e) => {
              (e.target as HTMLImageElement).src = `https://via.placeholder.com/400x600/1a1a2e/ffffff?text=${encodeURIComponent(movie.title)}`;
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <div className="bg-red-600 rounded-full p-4 transform scale-75 group-hover:scale-100 transition-transform duration-300">
              <Play className="w-6 h-6 text-white fill-white" />
            </div>
          </div>
          <div className="absolute top-2 left-2">
            <span className={`text-xs px-2 py-1 rounded-full font-semibold ${
              movie.status === 'now_showing'
                ? 'bg-green-600 text-white'
                : movie.status === 'coming_soon'
                ? 'bg-yellow-600 text-white'
                : 'bg-gray-600 text-white'
            }`}>
              {movie.status === 'now_showing' ? 'Now Showing' : movie.status === 'coming_soon' ? 'Coming Soon' : 'Ended'}
            </span>
          </div>
          <div className="absolute top-2 right-2 flex items-center gap-1 bg-black/70 backdrop-blur-sm px-2 py-1 rounded-full">
            <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
            <span className="text-white text-xs font-semibold">{movie.imdbRating}</span>
          </div>
        </div>
        <div className="p-3">
          <h3 className="text-white font-semibold text-sm line-clamp-1 group-hover:text-red-400 transition-colors">{movie.title}</h3>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex items-center gap-1 text-gray-400">
              <Clock className="w-3 h-3" />
              <span className="text-xs">{movie.duration}m</span>
            </div>
            <span className="text-gray-600">•</span>
            <span className="text-xs text-gray-400">{movie.rating}</span>
          </div>
          <div className="flex flex-wrap gap-1 mt-2">
            {movie.genre.slice(0, 2).map(g => (
              <span key={g} className="text-xs bg-gray-800 text-gray-300 px-2 py-0.5 rounded-full">{g}</span>
            ))}
          </div>
        </div>
      </div>
    </Link>
  );
}
