import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Film, Menu, X, LogOut, Ticket, LayoutDashboard } from 'lucide-react';
import { User as UserType } from '../types';

interface NavbarProps {
  currentUser: UserType | null;
  onLogout: () => void;
}

export default function Navbar({ currentUser, onLogout }: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dropOpen, setDropOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate('/');
    setDropOpen(false);
    setMenuOpen(false);
  };

  return (
    <nav className="bg-gray-900 border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="bg-red-600 p-1.5 rounded-lg group-hover:bg-red-500 transition-colors">
              <Film className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-white">
              C<span className="text-red-500">C</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            <Link to="/" className="text-gray-300 hover:text-white transition-colors text-sm font-medium">Home</Link>
            <Link to="/movies" className="text-gray-300 hover:text-white transition-colors text-sm font-medium">Movies</Link>
            {currentUser && (
              <Link to="/my-bookings" className="text-gray-300 hover:text-white transition-colors text-sm font-medium flex items-center gap-1">
                <Ticket className="w-4 h-4" /> My Bookings
              </Link>
            )}

          </div>

          {/* Auth */}
          <div className="hidden md:flex items-center gap-3">
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setDropOpen(!dropOpen)}
                  className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 px-3 py-2 rounded-lg transition-colors"
                >
                  <div className="w-7 h-7 bg-red-600 rounded-full flex items-center justify-center text-xs font-bold text-white">
                    {currentUser.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-sm text-white font-medium">{currentUser.name}</span>
                </button>
                {dropOpen && (
                  <div className="absolute right-0 mt-2 w-52 bg-gray-800 border border-gray-700 rounded-xl shadow-xl py-2 z-50">
                    <div className="px-4 py-2 border-b border-gray-700">
                      <p className="text-white font-semibold text-sm">{currentUser.name}</p>
                      <p className="text-gray-400 text-xs">{currentUser.email}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full mt-1 inline-block ${currentUser.role === 'admin' ? 'bg-yellow-600/20 text-yellow-400' : 'bg-blue-600/20 text-blue-400'}`}>
                        {currentUser.role}
                      </span>
                    </div>
                    <Link to="/my-bookings" onClick={() => setDropOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-gray-700 transition-colors">
                      <Ticket className="w-4 h-4" /> My Bookings
                    </Link>
                    {currentUser.role === 'admin' && (
                      <Link to="/admin" onClick={() => setDropOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-gray-700 transition-colors">
                        <LayoutDashboard className="w-4 h-4" /> Admin Panel
                      </Link>
                    )}
                    <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-gray-700 transition-colors w-full text-left">
                      <LogOut className="w-4 h-4" /> Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link to="/login" className="text-sm text-gray-300 hover:text-white transition-colors font-medium px-3 py-2">Login</Link>
                <Link to="/register" className="text-sm bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-lg transition-colors font-medium">Sign Up</Link>
              </>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden text-gray-400 hover:text-white">
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-gray-900 border-t border-gray-800 px-4 py-4 space-y-3">
          <Link to="/" onClick={() => setMenuOpen(false)} className="block text-gray-300 hover:text-white py-2 text-sm font-medium">Home</Link>
          <Link to="/movies" onClick={() => setMenuOpen(false)} className="block text-gray-300 hover:text-white py-2 text-sm font-medium">Movies</Link>

          {currentUser ? (
            <>
              <Link to="/my-bookings" onClick={() => setMenuOpen(false)} className="block text-gray-300 hover:text-white py-2 text-sm font-medium">My Bookings</Link>
              {currentUser.role === 'admin' && (
                <Link to="/admin" onClick={() => setMenuOpen(false)} className="block text-gray-300 hover:text-white py-2 text-sm font-medium">Admin Panel</Link>
              )}
              <button onClick={handleLogout} className="block text-red-400 hover:text-red-300 py-2 text-sm font-medium w-full text-left">Logout</button>
            </>
          ) : (
            <div className="flex gap-3 pt-2">
              <Link to="/login" onClick={() => setMenuOpen(false)} className="flex-1 text-center border border-gray-700 text-gray-300 py-2 rounded-lg text-sm font-medium">Login</Link>
              <Link to="/register" onClick={() => setMenuOpen(false)} className="flex-1 text-center bg-red-600 text-white py-2 rounded-lg text-sm font-medium">Sign Up</Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
