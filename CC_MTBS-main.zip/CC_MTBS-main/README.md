# 🎬 CC — Online Movie Booking System

<div align="center">

![CC Banner](https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200&h=300&fit=crop)

[![React](https://img.shields.io/badge/React-19.x-61DAFB?style=for-the-badge&logo=react&logoColor=black)](https://reactjs.org/)
[![Vite](https://img.shields.io/badge/Vite-7.x-646CFF?style=for-the-badge&logo=vite&logoColor=white)](https://vitejs.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.x-3178C6?style=for-the-badge&logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4.x-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white)](https://tailwindcss.com/)
[![MySQL](https://img.shields.io/badge/MySQL-8.x-4479A1?style=for-the-badge&logo=mysql&logoColor=white)](https://www.mysql.com/)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

**A full-featured online movie ticket booking platform built with React, Vite, TypeScript, and Tailwind CSS — backed by a MySQL database schema.**

[Features](#-features) • [Tech Stack](#-tech-stack) • [Getting Started](#-getting-started) • [Database](#-database-schema) • [Pages](#-pages--screens) • [AWS Deployment](#-aws-deployment)

</div>

---

## 📋 Table of Contents

- [Project Overview](#-project-overview)
- [Features](#-features)
- [Tech Stack](#-tech-stack)
- [Project Structure](#-project-structure)
- [Getting Started (Localhost)](#-getting-started-localhost)
- [Database Schema](#-database-schema)
- [Pages & Screens](#-pages--screens)
- [Demo Credentials](#-demo-credentials)
- [User Roles](#-user-roles)
- [AWS Deployment](#-aws-deployment)
- [AWS Architecture](#-aws-architecture)
- [Environment Variables](#-environment-variables)
- [API Endpoints (Backend Reference)](#-api-endpoints-backend-reference)
- [Contributing](#-contributing)
- [License](#-license)

---

## 🌟 Project Overview

**CC** is a modern, fully responsive Online Movie Booking System that allows users to:
- Browse currently showing and upcoming movies
- Select preferred theaters, dates, and showtimes
- Choose seats from an interactive seat map
- Manage bookings and cancellations

Admins can manage movies, theaters, shows, users, and bookings through a dedicated admin panel.

> **Note:** The frontend currently uses `localStorage` to simulate the MySQL database for demo purposes. The complete MySQL schema is included for backend integration.

---

## ✨ Features

### 👤 User Features
- 🔐 **Authentication** — Register & Login with form validation
- 🎥 **Browse Movies** — Filter by genre, language, status; sort by rating/title/date
- 🔍 **Search** — Search movies by title or director
- 📅 **Show Scheduling** — Select date, theater, and showtime
- 💺 **Seat Selection** — Interactive seat map with 3 tiers (Standard / Premium / Recliner)
- 🎟️ **Booking Confirmation** — Ticket card with unique booking reference & barcode
- 📋 **My Bookings** — View all bookings, cancel upcoming reservations
- 📱 **Fully Responsive** — Works on mobile, tablet, and desktop

### 🛡️ Admin Features
- 🎬 **Movie Management** — Add, edit, delete movies (CRUD)
- 🏛️ **Theater Management** — View and manage theaters
- 📊 **Booking Overview** — View all user bookings with revenue stats
- 👥 **User Management** — View all registered users
- 📈 **Dashboard Stats** — Total movies, users, bookings, revenue

### 🎨 UI/UX Features
- 🌙 **Dark Cinema Theme** — Elegant dark UI with red/gold accents
- 🎠 **Hero Carousel** — Auto-sliding banner on homepage
- ✨ **Smooth Animations** — Hover effects, transitions, loading states
- 🏷️ **Status Badges** — Now Showing / Coming Soon / Ended labels
- 🌟 **IMDb Ratings** — Displayed on every movie card

---

## 🛠️ Tech Stack

### Frontend
| Technology | Version | Purpose |
|-----------|---------|---------|
| **React** | 19.x | UI component framework |
| **Vite** | 7.x | Build tool & dev server |
| **TypeScript** | 5.x | Type-safe JavaScript |
| **Tailwind CSS** | 4.x | Utility-first styling |
| **React Router DOM** | 7.x | Client-side routing |
| **Lucide React** | Latest | Icon library |
| **clsx** | 2.x | Conditional class utility |
| **tailwind-merge** | 3.x | Tailwind class merging |

### Database
| Technology | Purpose |
|-----------|---------|
| **MySQL 8.x** | Primary relational database |
| **Redis** *(optional)* | Session caching & seat locking |

### Backend *(Reference / Integration Ready)*
| Technology | Purpose |
|-----------|---------|
| **Node.js + Express** | REST API server |
| **Prisma / Sequelize** | MySQL ORM |
| **JWT + bcrypt** | Authentication & password hashing |
| **Socket.io** *(optional)* | Real-time seat availability |

---

## 📁 Project Structure

```
cinebook/
├── public/                     # Static assets
├── src/
│   ├── components/             # Reusable UI components
│   │   ├── Navbar.tsx          # Top navigation bar
│   │   └── MovieCard.tsx       # Movie card component
│   ├── pages/                  # Application pages/routes
│   │   ├── HomePage.tsx        # Landing page with hero & movie grids
│   │   ├── MoviesPage.tsx      # Browse & filter all movies
│   │   ├── MovieDetailPage.tsx # Movie details + show selection
│   │   ├── SeatSelectionPage.tsx # Interactive seat map
│   │   ├── BookingConfirmPage.tsx # Booking success + ticket
│   │   ├── MyBookingsPage.tsx  # User's booking history
│   │   ├── LoginPage.tsx       # Login form
│   │   ├── RegisterPage.tsx    # Registration form
│   │   └── AdminPage.tsx       # Admin dashboard
│   ├── data/
│   │   └── db.ts               # MySQL schema + localStorage simulation
│   ├── types/
│   │   └── index.ts            # TypeScript interfaces & types
│   ├── utils/
│   │   └── cn.ts               # Class name utility
│   ├── App.tsx                 # Root component with routing
│   ├── main.tsx                # React entry point
│   └── index.css               # Global styles
├── index.html                  # HTML entry point
├── vite.config.ts              # Vite configuration
├── tsconfig.json               # TypeScript configuration
├── package.json                # Dependencies & scripts
└── README.md                   # Project documentation
```

---

## 🚀 Getting Started (Localhost)

### Prerequisites

Make sure you have the following installed:

```bash
node --version    # v18.x or higher
npm --version     # v9.x or higher
mysql --version   # MySQL 8.x
```

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/cinebook.git
cd cinebook
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Set Up MySQL Database

Start your MySQL server (no password required):

```bash
# Start MySQL (Linux/Mac)
sudo service mysql start

# Start MySQL (Windows)
net start mysql
```

Connect to MySQL and create the database:

```sql
mysql -u root

-- Create the database
CREATE DATABASE cinebook;
USE cinebook;

-- Run the schema (see Database Schema section below)
```

### 4. Run the Development Server

```bash
npm run dev
```

Open your browser at: **http://localhost:5173**

### 5. Build for Production

```bash
npm run build
npm run preview
```

---

## 🗄️ Database Schema

> MySQL connection config: `host=localhost, user=root, password='', database=cinebook`

```sql
-- ─────────────────────────────────────────────────────────────
-- CC MySQL Schema
-- Database: cc
-- Version: 1.0.0
-- ─────────────────────────────────────────────────────────────

CREATE DATABASE IF NOT EXISTS cinebook;
USE cinebook;

-- ─── USERS TABLE ─────────────────────────────────────────────
CREATE TABLE users (
  id          VARCHAR(36)           PRIMARY KEY,
  name        VARCHAR(100)          NOT NULL,
  email       VARCHAR(100)          NOT NULL UNIQUE,
  password    VARCHAR(255)          NOT NULL,
  role        ENUM('user','admin')  NOT NULL DEFAULT 'user',
  createdAt   DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ─── MOVIES TABLE ────────────────────────────────────────────
CREATE TABLE movies (
  id           VARCHAR(36)                              PRIMARY KEY,
  title        VARCHAR(200)                             NOT NULL,
  genre        JSON                                     NOT NULL,
  language     VARCHAR(50)                              NOT NULL,
  duration     INT                                      NOT NULL COMMENT 'in minutes',
  rating       VARCHAR(10)                              NOT NULL,
  imdbRating   DECIMAL(3,1)                             NOT NULL,
  description  TEXT                                     NOT NULL,
  posterUrl    TEXT                                     NOT NULL,
  bannerUrl    TEXT                                     NOT NULL,
  releaseDate  DATE                                     NOT NULL,
  cast         JSON                                     NOT NULL,
  director     VARCHAR(100)                             NOT NULL,
  status       ENUM('now_showing','coming_soon','ended') NOT NULL DEFAULT 'coming_soon',
  createdAt    DATETIME                                 NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ─── THEATERS TABLE ──────────────────────────────────────────
CREATE TABLE theaters (
  id          VARCHAR(36)  PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  location    VARCHAR(200) NOT NULL,
  totalSeats  INT          NOT NULL DEFAULT 60
);

-- ─── SHOWS TABLE ─────────────────────────────────────────────
CREATE TABLE shows (
  id              VARCHAR(36)   PRIMARY KEY,
  movieId         VARCHAR(36)   NOT NULL,
  theaterId       VARCHAR(36)   NOT NULL,
  date            DATE          NOT NULL,
  time            VARCHAR(10)   NOT NULL,
  price           DECIMAL(10,2) NOT NULL,
  availableSeats  JSON          NOT NULL,
  bookedSeats     JSON          NOT NULL DEFAULT '[]',
  createdAt       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (movieId)   REFERENCES movies(id)   ON DELETE CASCADE,
  FOREIGN KEY (theaterId) REFERENCES theaters(id) ON DELETE CASCADE
);

-- ─── BOOKINGS TABLE ──────────────────────────────────────────
CREATE TABLE bookings (
  id           VARCHAR(36)                    PRIMARY KEY,
  userId       VARCHAR(36)                    NOT NULL,
  movieId      VARCHAR(36)                    NOT NULL,
  showId       VARCHAR(36)                    NOT NULL,
  theaterId    VARCHAR(36)                    NOT NULL,
  seats        JSON                           NOT NULL,
  totalAmount  DECIMAL(10,2)                  NOT NULL,
  bookingDate  DATETIME                       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status       ENUM('confirmed','cancelled')  NOT NULL DEFAULT 'confirmed',
  bookingRef   VARCHAR(20)                    NOT NULL UNIQUE,

  FOREIGN KEY (userId)    REFERENCES users(id)    ON DELETE CASCADE,
  FOREIGN KEY (movieId)   REFERENCES movies(id)   ON DELETE CASCADE,
  FOREIGN KEY (showId)    REFERENCES shows(id)    ON DELETE CASCADE,
  FOREIGN KEY (theaterId) REFERENCES theaters(id) ON DELETE CASCADE
);

-- ─── INDEXES ─────────────────────────────────────────────────
CREATE INDEX idx_movies_status    ON movies(status);
CREATE INDEX idx_shows_movie      ON shows(movieId);
CREATE INDEX idx_shows_theater    ON shows(theaterId);
CREATE INDEX idx_shows_date       ON shows(date);
CREATE INDEX idx_bookings_user    ON bookings(userId);
CREATE INDEX idx_bookings_ref     ON bookings(bookingRef);
CREATE INDEX idx_bookings_status  ON bookings(status);
```

### Seat Tier Pricing

| Tier | Rows | Price Multiplier |
|------|------|-----------------|
| 🟢 Standard | A–D | Base price (e.g. $120) |
| 🔵 Premium | E–H | 1.5× base price |
| 🟣 Recliner | I–J | 2× base price |

---

## 📺 Pages & Screens

| Route | Page | Description |
|-------|------|-------------|
| `/` | **Home** | Hero carousel, Now Showing, Coming Soon |
| `/movies` | **Movies** | Browse, filter, search all movies |
| `/movies/:id` | **Movie Detail** | Movie info, date picker, show times |
| `/seat-selection/:showId` | **Seat Selection** | Interactive seat map + booking summary |
| `/booking-confirm/:bookingId` | **Booking Confirm** | Ticket card with booking reference |
| `/my-bookings` | **My Bookings** | User's booking history + cancel option |
| `/login` | **Login** | User login form |
| `/register` | **Register** | User registration form |
| `/admin` | **Admin Panel** | Admin dashboard (CRUD, stats) |

---

## 🔑 Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| 👑 **Admin** | `admin@cc.com` | `admin123` |
| 👤 **User** | `john@cc.com` | `john123` |
| 👤 **User** | `jane@example.com` | `jane123` |

> ⚠️ **Note:** Demo credentials are for testing purposes only. You can also register a new account directly from the Register page.
> These credentials are stored here in the README — there is **no demo login section** on the login page.

---

## 👥 User Roles

### Regular User
- Register / Login
- Browse and search movies
- Select seats and book tickets
- View and cancel bookings

### Admin
- All user permissions
- Add / Edit / Delete movies
- View all users
- View all bookings and revenue stats
- Manage theaters

---

## ☁️ AWS Deployment

### Architecture Overview

```
Internet
    │
    ▼
Route 53 (DNS)
    │
    ▼
CloudFront (CDN + SSL)
    │
    ├──────────────────────────────────┐
    ▼                                  ▼
S3 Bucket                     ALB (Load Balancer)
(React Static Files)               │
                                   ▼
                          ECS Cluster / EC2
                          (Node.js + Express API)
                               │
                    ┌──────────┼──────────┐
                    ▼          ▼          ▼
               RDS MySQL  ElastiCache   S3 Bucket
              (Database)   (Redis)    (Movie Posters)
                    │
                    ▼
               CloudWatch
               (Monitoring)
```

### Step-by-Step AWS Deployment

#### Step 1 — Build the Frontend

```bash
npm run build
# Output: dist/ folder
```

#### Step 2 — Deploy Frontend to S3 + CloudFront

```bash
# Create S3 bucket
aws s3 mb s3://cinebook-frontend --region us-east-1

# Upload build files
aws s3 sync dist/ s3://cinebook-frontend --delete

# Enable static website hosting
aws s3 website s3://cinebook-frontend \
  --index-document index.html \
  --error-document index.html

# Create CloudFront distribution (via AWS Console or CLI)
```

#### Step 3 — Set Up RDS MySQL (No Password Dev Mode)

```bash
# Create RDS instance (use AWS Console for GUI)
aws rds create-db-instance \
  --db-instance-identifier cinebook-db \
  --db-instance-class db.t3.micro \
  --engine mysql \
  --engine-version 8.0 \
  --master-username root \
  --master-user-password your_secure_password \
  --allocated-storage 20 \
  --db-name cinebook \
  --publicly-accessible
```

#### Step 4 — Deploy Backend to ECS / EC2

```bash
# Build Docker image
docker build -t cinebook-api .

# Push to ECR
aws ecr create-repository --repository-name cinebook-api
docker tag cinebook-api:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/cinebook-api:latest
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/cinebook-api:latest

# Deploy to ECS
aws ecs create-cluster --cluster-name cinebook-cluster
# (configure task definitions and services via AWS Console)
```

#### Step 5 — Set Up Route 53

```bash
# Create hosted zone
aws route53 create-hosted-zone \
  --name cinebook.yourdomain.com \
  --caller-reference $(date +%s)
```

---

## 🏗️ AWS Architecture

| AWS Service | Purpose | Tier |
|-------------|---------|------|
| **Route 53** | DNS management | Free tier eligible |
| **CloudFront** | CDN + HTTPS | Pay per request |
| **S3** | Frontend hosting + media | ~$0.023/GB |
| **ALB** | Load balancer | ~$0.008/LCU-hour |
| **ECS Fargate** | Backend API containers | Pay per vCPU/memory |
| **EC2 (t3.micro)** | Alternative to ECS | ~$8.35/month |
| **RDS MySQL (t3.micro)** | Primary database | ~$15/month |
| **ElastiCache Redis** | Seat lock caching | ~$15/month |
| **CloudWatch** | Logs & monitoring | Free tier eligible |
| **ACM** | SSL/TLS certificates | Free |
| **IAM** | Access management | Free |

### 💰 Estimated Monthly Cost (Small Scale)

| Service | Est. Cost/Month |
|---------|----------------|
| EC2 t3.medium (Backend) | $30–50 |
| RDS MySQL db.t3.micro | $15–25 |
| ElastiCache Redis | $15–20 |
| S3 + CloudFront | $5–10 |
| ALB | $5–10 |
| Route 53 + ACM | $1–5 |
| CloudWatch | $0–5 |
| **Total Estimate** | **~$71–125/month** |

---

## 🔧 Environment Variables

Create a `.env` file in the project root:

```env
# ─── App ───────────────────────────────────────────
VITE_APP_NAME=CC
VITE_APP_VERSION=1.0.0

# ─── API (Backend) ─────────────────────────────────
VITE_API_BASE_URL=http://localhost:5000/api

# ─── MySQL (Backend .env) ──────────────────────────
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=cinebook

# ─── JWT ───────────────────────────────────────────
JWT_SECRET=your_super_secret_key
JWT_EXPIRES_IN=7d

# ─── AWS (Production) ──────────────────────────────
AWS_REGION=us-east-1
AWS_S3_BUCKET=cinebook-media
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
```

---

## 📡 API Endpoints (Backend Reference)

### Authentication
```
POST   /api/auth/register     Register new user
POST   /api/auth/login        Login user
GET    /api/auth/me           Get current user
```

### Movies
```
GET    /api/movies            Get all movies (with filters)
GET    /api/movies/:id        Get single movie
POST   /api/movies            Create movie (Admin)
PUT    /api/movies/:id        Update movie (Admin)
DELETE /api/movies/:id        Delete movie (Admin)
```

### Shows
```
GET    /api/shows             Get all shows
GET    /api/shows/:id         Get single show
GET    /api/shows/movie/:id   Get shows by movie
POST   /api/shows             Create show (Admin)
PUT    /api/shows/:id/seats   Update booked seats
```

### Theaters
```
GET    /api/theaters          Get all theaters
GET    /api/theaters/:id      Get single theater
POST   /api/theaters          Create theater (Admin)
```

### Bookings
```
GET    /api/bookings          Get user's bookings
GET    /api/bookings/:id      Get single booking
POST   /api/bookings          Create booking
PUT    /api/bookings/:id/cancel  Cancel booking
GET    /api/admin/bookings    Get all bookings (Admin)
```

### Users *(Admin)*
```
GET    /api/admin/users       Get all users
GET    /api/admin/users/:id   Get single user
DELETE /api/admin/users/:id   Delete user
```

---

## 🔄 Data Flow

```
User Action (e.g., Book Seat)
        │
        ▼
React Component (SeatSelectionPage)
        │
        ▼
localStorage / API call
        │
        ▼
MySQL Database (shows table → update bookedSeats)
        │
        ▼
MySQL Database (bookings table → insert new booking)
        │
        ▼
Redirect to BookingConfirmPage
        │
        ▼
Display Ticket with Booking Reference
```

---

## 🧪 Running Tests

```bash
# Unit tests (if configured)
npm run test

# E2E tests (if configured)
npm run test:e2e
```

---

## 🐳 Docker Setup (Local Development)

Create a `docker-compose.yml` file:

```yaml
version: '3.8'

services:
  frontend:
    build: .
    ports:
      - "5173:5173"
    depends_on:
      - backend

  backend:
    image: node:18-alpine
    working_dir: /app
    volumes:
      - ./backend:/app
    ports:
      - "5000:5000"
    environment:
      - DB_HOST=mysql
      - DB_USER=root
      - DB_PASSWORD=
      - DB_NAME=cinebook
    depends_on:
      - mysql

  mysql:
    image: mysql:8.0
    ports:
      - "3306:3306"
    environment:
      - MYSQL_ROOT_PASSWORD=
      - MYSQL_ALLOW_EMPTY_PASSWORD=yes
      - MYSQL_DATABASE=cinebook
    volumes:
      - mysql_data:/var/lib/mysql
      - ./schema.sql:/docker-entrypoint-initdb.d/schema.sql

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  mysql_data:
```

Run with:

```bash
docker-compose up -d
```

---

## 📸 Screenshots

| Page | Description |
|------|-------------|
| 🏠 **Home** | Hero carousel with Now Showing & Coming Soon sections |
| 🎥 **Movies** | Filter/search grid with movie cards |
| 🎞️ **Movie Detail** | Full info + theater/date/show picker |
| 💺 **Seat Map** | Color-coded interactive seat selection |
| 🎟️ **Ticket** | Booking confirmation with barcode |
| 📋 **My Bookings** | Booking history with cancel option |
| 🛡️ **Admin Panel** | CRUD dashboard with stats cards |

---

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch: `git checkout -b feature/AmazingFeature`
3. Commit your changes: `git commit -m 'Add some AmazingFeature'`
4. Push to the branch: `git push origin feature/AmazingFeature`
5. Open a Pull Request

---

## 📌 Roadmap

- [ ] Connect to real MySQL backend (Node.js/Express)
- [ ] Real-time seat locking with Socket.io + Redis
- [ ] QR code generation for tickets
- [ ] Multi-language support (i18n)
- [ ] Dark/Light theme toggle
- [ ] Mobile app (React Native)
- [ ] Admin analytics charts (revenue, occupancy)
- [ ] Movie trailer integration (YouTube embed)

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.

---

## 👨‍💻 Author

**CC Development Team**

> Built with ❤️ using React, Vite, TypeScript, Tailwind CSS & MySQL

---

<div align="center">

⭐ **Star this repo if you found it helpful!** ⭐

</div>
